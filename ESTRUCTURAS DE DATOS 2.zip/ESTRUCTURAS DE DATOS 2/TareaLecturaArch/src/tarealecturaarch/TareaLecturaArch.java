/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tarealecturaarch;

import java.io.*;
import java.util.*;

/**
 *
 * @author SOFIA
 */
public class TareaLecturaArch {
    public static void main(String[] args) {
        /*try (FileReader fe = new FileReader(args[0])) {
            BufferedReader br = new BufferedReader(fe);
            String ln;
            Scanner sc;
            long words = 0;
            while((ln=br.readLine())!=null){
                sc = new Scanner(ln);
                while (sc.hasNext()) {
                    sc.next();
                    words++;
                }
            }
            System.out.printf("File\"%s\"has%dwords", args[0], words);
        } 
        catch (Exception e) {
            System.out.println("No valid file specified");
        }*/
        
        System.out.println("Imprime Archivo" + lectArchRec("Alumnos.txt"));
    }
    

    public static int lecturaArch(String nomArch) {
        int cont = 0;
       // T dato;
        try (Scanner leeArch = new Scanner(new File(nomArch))){
            while (leeArch.hasNext()) {
                leeArch.next();
                cont++;
            }
            leeArch.close();
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            cont=-1;
        }
        return cont;
    }
    
    public static int lectArchRec(String nomArch){
        int cont;
        try(Scanner lee = new Scanner(new File (nomArch))){
            return lectArchRec(0, lee);
        }catch(Exception e){
             return cont=-1;
        }
    }
        
    private static int lectArchRec(int cont, Scanner lee){
        if(lee.hasNext()){
            lee.next();
            return lectArchRec(cont+1, lee);
        }
        lee.close();;
        return cont;
    }
    
   /* public static String lecturaArchRec(String nomArch){
        StringBuilder str = new StringBuilder();
        
    }*/

    /*public static double lecturaArchivo(String nom) {
        try {
            FileInputStream file = new FileInputStream(nom);
            ObjectInputStream lee = new ObjectInputStream(file);
            boolean bandera = true;
            StringBuilder str = new StringBuilder();
            int cont = 0;
            while (bandera) {
                try {
                    str.append(lee.readObject());
                    cont++;
                } catch (IOException e) {
                    bandera = false;
                }
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return cont;
    }*/

}