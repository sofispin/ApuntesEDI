/*
 *
 */
package doblecola;

/**
 *
 * @author EMILIA SOFIA SPINOLA CAMPOS Y RUBEN ANDRES GIMENEZ SANTANDER
 */
public class DobleCola {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        //DOBLE COLA
        //Prueba Doble Cola de tipo Integer
        DobleColaA<Integer> dobleCola = new DobleColaA();
        dobleCola.insertarFin(1);
        dobleCola.insertarFin(2);
        dobleCola.insertaInicio(3);
        dobleCola.insertarFin(4);
        dobleCola.eliminarFin();
        dobleCola.eliminarInicio();
        dobleCola.insertaInicio(5);
        dobleCola.insertaInicio(6);
        dobleCola.insertaInicio(7);
        dobleCola.insertaInicio(8);
        dobleCola.insertarFin(9);
        dobleCola.insertaInicio(10);
        dobleCola.insertarFin(11);
        dobleCola.insertaInicio(12);
        dobleCola.insertarFin(13);
        dobleCola.insertaInicio(14);
        dobleCola.insertarFin(15);
        dobleCola.insertaInicio(16);
        dobleCola.insertarFin(17);
        dobleCola.eliminarInicio();
        dobleCola.eliminarFin();

        System.out.println("Prueba Doble Cola de tipo Integer: ");
        System.out.println("Doble Cola Integer: " + dobleCola.toString());
        System.out.println("Consulta Primero: " + dobleCola.consultaPrimero());
        System.out.println("Consulta Ultimo: " + dobleCola.consultaUltimo());
        System.out.println("Vacia: " + dobleCola.isEmpty() + "\n");

        //Prueba Doble Cola de tipo String 
        DobleColaA<String> dobleCola1 = new DobleColaA();
        dobleCola1.insertaInicio("Es");
        dobleCola1.insertarFin("tru");
        dobleCola1.insertaInicio("ctu");
        dobleCola1.insertarFin("ras");

        System.out.println("Prueba Doble Cola de tipo String: ");
        System.out.println("Doble Cola String: " + dobleCola1.toString());
        System.out.println("Consulta Primero: " + dobleCola1.consultaPrimero());
        System.out.println("Consulta Ultimo: " + dobleCola1.consultaUltimo());
        System.out.println("Vacia: " + dobleCola1.isEmpty() + "\n");

        //Prueba Doble Cola de tipo Boolean
        DobleColaA<Boolean> dobleCola2 = new DobleColaA();
        dobleCola2.insertarFin(true);
        dobleCola2.insertarFin(false);
        dobleCola2.insertaInicio(true);
        dobleCola2.insertarFin(false);

        System.out.println("Prueba Doble Cola de tipo Boolean: ");
        System.out.println("Doble Cola Boolean: " + dobleCola2.toString());
        System.out.println("Consulta Primero: " + dobleCola2.consultaPrimero());
        System.out.println("Consulta Ultimo: " + dobleCola2.consultaUltimo());
        System.out.println("Vacia: " + dobleCola2.isEmpty() + "\n");

        //Prueba Doble Cola de tipo Character
        DobleColaA<Character> dobleCola3 = new DobleColaA();
        dobleCola3.insertaInicio('b');
        dobleCola3.insertarFin('c');
        dobleCola3.insertaInicio('a');
        dobleCola3.insertarFin('d');

        System.out.println("Prueba Doble Cola de tipo Character: ");
        System.out.println("Doble Cola Character: " + dobleCola3.toString());
        System.out.println("Consulta Primero: " + dobleCola3.consultaPrimero());
        System.out.println("Consulta Ultimo: " + dobleCola3.consultaUltimo());
        System.out.println("Vacia: " + dobleCola3.isEmpty() + "\n");

        //Prueba Doble Cola Vacia
        DobleColaA<Double> dobleCola4 = new DobleColaA();
        System.out.println("Prueba Doble Cola de tipo Double: ");
        System.out.println("Doble Cola Double: " + dobleCola4.toString());
        System.out.println("Consulta Primero: " + dobleCola4.consultaPrimero());
        System.out.println("Consulta Ultimo: " + dobleCola4.consultaUltimo());
        System.out.println("Vacia: " + dobleCola4.isEmpty() + "\n");
    }
    
}
