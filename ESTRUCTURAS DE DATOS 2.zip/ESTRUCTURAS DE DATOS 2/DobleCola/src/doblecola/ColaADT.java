/*
 * 
 */
package doblecola;

/**
 *
 * @author EMILIA SOFIA SPINOLA CAMPOS Y RUBEN ANDRES GIMENEZ SANTANDER
 */
public interface ColaADT <T> {
    
    public void insertarFin(T dato);
    public void insertaInicio(T dato);
    public T eliminarInicio();
    public T eliminarFin();
    public boolean isEmpty();
    public T consultaPrimero();
    public T consultaUltimo();
}
