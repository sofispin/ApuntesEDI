/*
 * 
 */
package doblecola;

/**
 *
 * @author EMILIA SOFIA SPINOLA CAMPOS Y RUBEN ANDRES GIMENEZ SANTANDER
 */
public class DobleColaA <T> implements ColaADT <T>{
    
    private T[] dobleCola;
    private int inicio;
    private int fin;
    private final int MAX = 20;
    
    /**
     * Constructor.
     */
    public DobleColaA() {
        dobleCola = (T[]) new Object[MAX];
        inicio = -1;
        fin = -1;

    }
    
    /**
     * Constructor.
     * @param max 
     */
    public DobleColaA(int max) {
        dobleCola = (T[]) new Object[max];
        inicio = -1;
        fin = -1;
    }
    
    /**
     * Inserta al final de la Doble Cola.
     * @param dato 
     */
    public void insertarFin(T dato) { 
        if ((fin + 1) % dobleCola.length == inicio) {
            expandCapacity();
        }
        fin = (fin + 1) % dobleCola.length;
        dobleCola[fin] = dato;
        if (inicio == -1) {
            inicio = 0;
        }
    }
    
    /**
     * Inserta al inicio de la Doble Cola.
     * @param dato 
     */
    public void insertaInicio(T dato) {
        //inicio+1
        if ((inicio - 1) % dobleCola.length == inicio) {
            expandCapacity();
        }
        if (inicio == fin) {
            inicio = (inicio - 1 + dobleCola.length) % dobleCola.length;
            fin = (inicio + 1) % dobleCola.length;
            dobleCola[inicio] = dato;
            if (dobleCola[fin] == null) {
                eliminarFin();
            }
        } else {
            inicio = (inicio - 1 + dobleCola.length) % dobleCola.length;
            dobleCola[inicio] = dato;
        }
        if (fin == -1) {
            fin = 0;
        }
    }
    
    /**
     * Elimina el elemento al inicio de la Doble Cola.
     * @return resul
     */
    public T eliminarInicio() {
        if (isEmpty()) {
            throw new EmptyCollectionException("Cola Vacia");
        }
        T resul;
        resul = dobleCola[inicio];
        dobleCola[inicio] = null;
        if (inicio == fin) {
            inicio = -1;
            fin = -1;
        } else {
            inicio = (inicio + 1) % dobleCola.length;
        }
        return resul;
    }

    /**
     * Elimina al final de la Doble Cola. 
     * @return resul
     */
    public T eliminarFin() {
        if (isEmpty()) {
            throw new EmptyCollectionException("Cola Vacia");
        }
        T resul;
        resul = dobleCola[fin];
        dobleCola[fin] = null;
        if (inicio == fin) {
            inicio = -1;
            fin = -1;
        } else {
            fin = (fin - 1) % dobleCola.length;
        }
        return resul;
    }

    /**
     * Indica si la Doble Cola esta vacia o no.
     * @return boolean
     */
    public boolean isEmpty() {
        return inicio == -1;
    }
    
    /**
     * Regresa el primer elemento de la Doble Cola si no esta vacia. 
     * @return elemento
     */
    public T consultaPrimero() {
        if (isEmpty()) {
            throw new EmptyCollectionException("Doble Cola Vacia");
        }
        return dobleCola[inicio];
    }
    
    /**
     * Regresa el ultimo elemento de la Doble Cola si no esta vacia. 
     * @return elemento
     */
    public T consultaUltimo() {
        if (isEmpty()) {
            throw new EmptyCollectionException("Doble Cola Vacia");
        }
        return dobleCola[fin];
    }

    /**
     * Metodo privado que expande la capacidad de la DobleCola si 
     * se encuentra llena.
     */
    private void expandCapacity() {
        T[] nuevo = (T[]) new Object[dobleCola.length * 2];
        int i, j = 0;

        for (i = inicio; i < dobleCola.length; i++) {
            nuevo[j] = dobleCola[i];
            j++;
        }
        for (i = 0; i < inicio; i++) {
            nuevo[j] = dobleCola[i];
            j++;
        }
        dobleCola = nuevo;
        inicio = 0;
        fin = j - 1;
    }

    /**
     * toString 
     * @return String
     */
    public String toString() {
        StringBuilder str = new StringBuilder();
        DobleColaA aux = new DobleColaA();

        while (!isEmpty()) {
            aux.insertarFin(this.consultaPrimero());
            str.append(this.eliminarInicio());
            str.append(" ");
        }
        while (!aux.isEmpty()) {
            this.insertarFin((T) aux.eliminarInicio());
        }

        return str.toString();
    }

}
