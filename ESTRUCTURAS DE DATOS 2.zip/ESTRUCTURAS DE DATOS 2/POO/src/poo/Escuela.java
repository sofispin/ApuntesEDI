/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package poo;

/**
 *
 * @author SOFIA
 */
public class Escuela {
    // ATRIBUTOS
    private String nombreEscuela;
    private String direccionEscuela;
    private int numAlumnos;
    private final int MAXALUMNOS = 50;
    private Alumno [] alumnosCar;
    
    // CONSTRUCTORES
    public Escuela() {
        nombreEscuela = "Miraflores";
        direccionEscuela = "GBaz";
        numAlumnos = 0;
        alumnosCar = new Alumno[MAXALUMNOS];
    }

    public Escuela(String nEsc, String dEsc) {
        this();
        nombreEscuela = nEsc;
        direccionEscuela = dEsc;
    }

    // SET-TERS y GET-TERS
    public void setNombreEscuela(String nEsc) {
        nombreEscuela=nEsc;
    }

    public void setDireccionEscuela(String dEsc) {
        direccionEscuela=dEsc;
    }
    
    public String getNombreEscuela() {
        return nombreEscuela;
    }
    
    public String getDireccionEscuela() {
        return nombreEscuela;
    }

    // Metodo para dar de alta un alumno.
    public boolean altaAlumno(Alumno alump) {
        boolean sePudo = false;
        if (numAlumnos<this.MAXALUMNOS){
            this.alumnosCar[numAlumnos]=alump;
            numAlumnos++;
            sePudo=true;
        }
        return sePudo;
    }
    
    // Metodo para obtener los datos de un alumno segun su clave
    // Situaciones: No existe el alumno, no existe ningun alumno.
    public String infoAlumnoClv(int claUn) {
        int i=0;
	boolean loEncontre = false;
        String info = "";
        while (i<numAlumnos && !loEncontre) {
            if (alumnosCar[i].getClaveUnica() == claUn){
		loEncontre = true;
            }
            else {
                i++;
            }
            if(loEncontre == true)
             info = alumnosCar[i].toString();
        }
         return info;
    }
    
    // Nombre y promedio de todos los alumnos 
    public String calculoPromedioTodos(){
        String info="";
        for (int i = 0; i < numAlumnos; i++) {
            info = info + "\n" + alumnosCar[i].getNombreAlum() + " - " + alumnosCar[i].calculaPromedio();
        }
        return info;
    }
    
    // Nombre de alumno con mayor cantidad de materias aprobadas
      public String mayorMateriasAprob() {
        String cade;
        cade = "";
	int max = 0;
	for (int i = 0; i < numAlumnos; i++){
            int num = 0;
            for(int j=0; j<alumnosCar[i].getCalificaciones().length;j++)
		if(alumnosCar[i].getCalificaciones()[j]>5)
                    num++;
            
            if(num>max){
                max= num;
		cade=alumnosCar[i].getNombreAlum();
            }		
	}
        return cade;        
    }
}
