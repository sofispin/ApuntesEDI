/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package poo;

/**
 * 
 *
 * @author SOFIA
 */
public class POO {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("Hola");
        
        //Problema 1
        //Complejo Vacacional-Rectangulo
      /*  Rectangulo alb1 = new Rectangulo(1,2);
        Rectangulo alb2 = new Rectangulo(2,3);*/
        ComplejoVacacional vac= new ComplejoVacacional("Hola");
        
        vac.agregarAlberca(1, 2);
        vac.agregarAlberca(2, 3);
        
        System.out.println("Cerca:" + vac.calcularCerca());
        System.out.println("Lona:" + vac.calcularSuperficie());
        
        //Problema 2
        Restaurante rest=new Restaurante("Hola");
        
        rest.agregarMesas(2);
        rest.agregarMesas(5);
        
        System.out.println("Lados: " + rest.calcularLados());
        System.out.println("Manteles: " + rest.calcularManteles());
        
        //Problema 3
         Alumno alu1, alu2, alu3;
        Escuela esc1, esc2;
        
        //Creacion de los Alumnos
        alu1 = new Alumno("Maria");
        alu1.altaCalificacion(9.1);
        
        alu2 = new Alumno("Juan");
        alu2.altaCalificacion(9.1);
        alu2.altaCalificacion(8.9);
        
        alu3 = new Alumno("Margarita");
        alu3.altaCalificacion(9.1);
        alu3.altaCalificacion(8.9);
        alu3.altaCalificacion(9.0);
        
        // Promedio de alu3
        System.out.println("\nAlumno: " + alu3.getNombreAlum() + " - "
            + alu3.calculaPromedio());
        
        // Info de alu2
        System.out.println("\n" + alu2.toString());
        
        // Creacion de escuelas
        esc1 = new Escuela("Miraflores", "GBAZ, CDMX");
        
        // Agregando alumnos
        esc1.altaAlumno(alu2);
        esc1.altaAlumno(alu3);
        
        // Promedio de todos los alumnos de esc1
        System.out.println("Promedios de la escuela " + esc1.getNombreEscuela());
        System.out.println(esc1.calculoPromedioTodos()+"\n");
        
        
        //Problema 4

        // 1) Se crea la empresa y se dan de alta los empleados.
        Empresa e= new Empresa("Oracle","Calle 1-10","Albert");
        e.altaEmpleado("Rebeca", 15000,"Computación", "5405");
        e.altaEmpleado("Pablo",20000, "Mate","3160");
        e.altaEmpleado("Juan", 6000, "Ing. Ind.","8943");
        e.altaEmpleado("Paco",6000,10); 
        e.altaEmpleado("Hugo",7000,15); 
        e.altaEmpleado("Luis",7500,5);

        // 2) Genera reporte de los administartivos.
        System.out.println(e.reporteAdmons());   

        // 3) Aumento a un administrativo.
        if(e.aumentoAdmon(102, 0.10)) {
            System.out.println("Aumento exitoso");
            System.out.println(e.toString());
        }
        else  {
              System.out.println("El administrativo no existe");
        }   
    }
    
}
