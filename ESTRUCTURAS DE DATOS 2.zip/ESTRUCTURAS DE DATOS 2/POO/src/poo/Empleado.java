/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package poo;

import java.util.Objects;

/**
 *
 * @author SOFIA
 */
public class Empleado {
    
    private static int serie =100;
    private int claveEmpleado;
    private String nombreEmpleado;
    private double sueldoBase;

    public Empleado() {
    this.claveEmpleado=serie++;
    this.nombreEmpleado="No hay nombre empleado";
    }

    public Empleado(String nombreEmpleado, double sueldoBase) {
        this.nombreEmpleado = nombreEmpleado;
        this.sueldoBase = sueldoBase;
        this.claveEmpleado=serie++;
    }

    public String getNombreEmpleado() {
        return nombreEmpleado;
    }

    public double getSueldoBase() {
        return sueldoBase;
    }

    public int getClaveEmpleado() {
        return claveEmpleado;
    }

    public void setSueldoBase(double sueldoBase) {
        this.sueldoBase = sueldoBase;
    }

    @Override
    public String toString() {
        StringBuilder str = new StringBuilder();
        str.append("Empleado: " + claveEmpleado + "\n");
        str.append("Nombre Empleado: " + nombreEmpleado + "\n");
        str.append("Sueldo Base: " + sueldoBase + "\n");
        
        return str.toString();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Empleado other = (Empleado) obj;
        if (this.claveEmpleado != other.claveEmpleado) {
            return false;
        }
        if (Double.doubleToLongBits(this.sueldoBase) != Double.doubleToLongBits(other.sueldoBase)) {
            return false;
        }
        if (!Objects.equals(this.nombreEmpleado, other.nombreEmpleado)) {
            return false;
        }
        return true;
    }
    
   public double calculaSalario(double prestac, double deduc){
       return sueldoBase *(1 + prestac-deduc);
   }
    
    
}
