/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package poo;

/**
 *
 * @author SOFIA
 */
public class ComplejoVacacional {
    
    private String nombre;
    private int numAlb;
    private final int MAX=10;
    private Rectangulo[] arrAlbercas;

    public ComplejoVacacional(String nombre) {
        this.nombre = nombre;
        this.arrAlbercas= new Rectangulo[MAX];
        this.numAlb=0;
    }

    public boolean agregarAlberca (double lado1, double lado2){
       boolean sePudo=false;
        if(numAlb<MAX){
           Rectangulo objA= new Rectangulo (lado1,lado2);
           arrAlbercas[numAlb]=objA;
           sePudo=true;
           numAlb ++;
        }
      return sePudo;
    }
    
    public double calcularSuperficie(){
        int i=0;
        double suma=0;
        while(i<numAlb){
        //for(int i=0; i<numAlberca; i++)
            suma= suma + arrAlbercas[i].calculaArea();
            i++;
        }
        return suma;
    }
    
    public double calcularCerca(){
        int j=0;
        double suma=0;
        while(j<numAlb){
            suma=suma+arrAlbercas[j].calculaPerimetro();
            j++;
        }
        return suma;
    }
}
