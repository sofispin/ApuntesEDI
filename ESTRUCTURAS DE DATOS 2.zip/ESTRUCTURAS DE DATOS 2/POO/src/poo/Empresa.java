/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package poo;

/**
 *
 * @author SOFIA
 */
public class Empresa{
    
    private String nombreEmpresa;
    private String direccion;
    private String nombreDueno;
    private Administrativo[] admins;
    private Operario[] operarios;
    private final int MAX=100;
    private int totalAdm;
    private int totalOp;

    public Empresa(String nombreEmpresa, String direccion, String nombreDueno) {
        this.nombreEmpresa = nombreEmpresa;
        this.direccion = direccion;
        this.nombreDueno = nombreDueno;
        this.admins= new Administrativo[MAX];
        this.operarios = new Operario[MAX];
        this.totalAdm=0;
        this.totalOp=0;
    }

    @Override
    public String toString() {
        return "Empresa{" + "nombreEmpresa=" + nombreEmpresa + ", direccion=" + direccion + ", nombreDueno=" + nombreDueno + '}';
    }
    
    public boolean altaEmpleado(String nombreEmpleado, double sueldoBase, String departamento, String telefono){
        boolean sePudo= false;
        if(totalAdm<MAX){
            admins[totalAdm]= new Administrativo(nombreEmpleado, sueldoBase, departamento, telefono);
            totalAdm++;
            sePudo=true;
        }
        return sePudo;
    }
    
    public boolean altaEmpleado(String nombreEmpleado, double sueldoBase, int horasExtra){
        boolean sePudo= false;
        if(totalOp<MAX){
            operarios[totalOp]= new Operario(nombreEmpleado, sueldoBase, horasExtra);
            totalOp++;
            sePudo=true;
        }
        return sePudo;
    }
    
    public boolean aumentoAdmon(int claveEmpleado, double porcentajeAumento){
        boolean sePudo=false;
        int pos=busquedaAdmon(claveEmpleado);
        
        if (pos != -1){
            this.admins[pos].setSueldoBase(this.admins[pos].getSueldoBase() * (1+(porcentajeAumento/100)));
            sePudo = true;
        }
        return sePudo;
    }
    
    public int busquedaAdmon(int claveEmpleado){
        int pos=-1;
        int i=0;
        while(i<MAX && pos==-1){
            if(this.admins[i].getClaveEmpleado() == claveEmpleado){
                pos = i;
            }
            i++;
        }
        return pos;
    }
    
    public int busquedaOper(int claveEmpleado){
        int pos=-1;
        int i=0;
        while(i<MAX && pos==-1){
            if(this.operarios[i].getClaveEmpleado() == claveEmpleado){
                pos = i;
            }
            i++;
        }
        return pos;
    }
    
    public boolean cambioDepartamento(int claveEmpleado, String nombreDepto){
        boolean sePudo= false;
        int pos = busquedaAdmon(claveEmpleado);
        if (pos!=-1){
            this.admins[pos].setDepartamento(nombreDepto);
            sePudo=true;
        }
        return sePudo;
    }
    
    public String reporteAdmons(){
        StringBuilder str = new StringBuilder();
        for(int i=0; i<this.totalAdm; i++){
            str.append("Nombre Empleado: " + this.admins[i].getNombreEmpleado());
            str.append("Sueldo Base: " + this.admins[i].getSueldoBase());
            str.append("\n");
        }
        
        return str.toString();
    }
    
    public String reporteOperarios(){
        StringBuilder str = new StringBuilder();
        for(int i=0; i<this.totalOp; i++){
            str.append("Nombre Empleado: " + this.operarios[i].getNombreEmpleado());
            str.append("Sueldo Base: " + this.operarios[i].getSueldoBase());
            str.append("\n");
        }
        
        return str.toString();
    }
    
    public String reporteOperarios(double sueldoParametro){
        StringBuilder str= new StringBuilder();
        int i=0; int cont =0;
        str.append("Operarios con sueldo base menor a " + sueldoParametro);
        while(i<this.totalOp){
            if(this.operarios[i].getSueldoBase()<sueldoParametro){
                str.append("Nombre: " + this.operarios[i].getNombreEmpleado());
                str.append("\n");
                cont++;
            }
            i++;
        }
        str.append("Numero de operarios con Sueldo menor a " + sueldoParametro + ": " + cont);
        
        return str.toString();
    }
    public String nominaAdmons(double prestac, double deduc){
        StringBuilder str = new StringBuilder();
        double nomina=0; double salario=0;
        int i=0;
        while (i<this.totalAdm){
            salario= this.admins[i].calculaSalario(prestac, deduc);
            str.append(salario + "\n");
            nomina += salario;
            i++;
        }
        str.append("Nomina total de la empresa(Admons): " + nomina);
        return str.toString();
    }
    
}
