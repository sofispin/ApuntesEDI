/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package poo;

/**
 *
 * @author SOFIA
 */
public class Administrativo extends Empleado{
    
    private String departamento;
    private String telefono;

    public Administrativo() {
        super();
    }

    public Administrativo(String nombreEmpleado, double sueldoBase, String departamento, String telefono) {
        super(nombreEmpleado, sueldoBase);
        this.departamento = departamento;
        this.telefono = telefono;
    }

    public String toString() {
        StringBuilder str= new StringBuilder();
        str.append(super.toString());
        str.append("Departamento:" + departamento + "\n");
        str.append("Telefono:" + telefono + "\n");
        
        return str.toString();
    }

    public String getDepartamento() {
        return departamento;
    }

    public void setDepartamento(String departamento) {
        this.departamento = departamento;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }
    
    
    
}
