/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package poo;

/**
 *
 * @author SOFIA
 */
public class Restaurante {
    
    public String nombre;
    public int numMesas;
    private final int MAX=25;
    private Cuadrado[] arrMesas;

    public Restaurante(String nombre) {
        this.nombre = nombre;
        this.numMesas = 0;
        this.arrMesas = new Cuadrado[MAX];
    }
    
    public boolean agregarMesas(double lado){
        boolean sePudo = false;
        if (numMesas<MAX){
            Cuadrado mesa = new Cuadrado(lado);
            arrMesas[numMesas]=mesa;
            sePudo=true;
            numMesas++;
        }
        return sePudo;
    }
    
    public double calcularManteles(){
        int i =0;
        double suma=0;
        while(i<numMesas){
            suma = suma + arrMesas[i].calculaArea();
            i++;
        }
        return suma;
    }
    
    public double calcularLados(){
        int i =0;
        double suma=0;
        while (i<numMesas){
            suma = suma+arrMesas[i].calculaPerimetro();
            i++;
        }
        return suma;
    }
}
