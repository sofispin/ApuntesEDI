/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arreglosbidimensionales;

/**
 *
 * @author SOFIA
 */
public class ArreglosBidimensionales {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        //Arreglo 2x3 (dos renglones, 3 columnas)
        double[][] mat={{2,9,3},{5,6,2}};
        
        mat.toString();
        
        System.out.println("Matriz Magica:" + matrizMagica(5));
    }
    
    public static String imprimeLineas(ArregloBidimensional arr){
        StringBuilder str = new StringBuilder();
        if(arr != null){
            return imprimeLineas(arr, str, 0, 0);
        }else{
            return str.toString();
        }
    }
    
    public static String imprimeLineas(ArregloBidimensional arr, StringBuilder str, int ren, int col){
        if(ren == arr.getTotRen()-1 && col==arr.getTotCol()-1){
            return str.toString();
        }else if(col != arr.getTotCol()-1){
            str.append(arr); 
            return imprimeLineas(arr,str,ren,col+1);
        }else{
            str.append(arr);
            return imprimeLineas(arr,str,ren+1,0); 
        }
    }
    
    public static double[][] matrizMagica(int n){
        if(n>0 && n%2!=0){
            double[][] matriz = new double[n][n];
            return matrizMagica(matriz, n, 1, 0, n/2);
        }else{
            throw new NullPointerException();
        }
    }
    
    private static double[][] matrizMagica(double[][] matriz, int n, int num, int ren, int col){
        matriz[ren][col]=num;
        if(num == n*n){
            return matriz;
        }else{
            if(num%n ==0){
                ren++;
            }else{
                ren--;
                col++;
                if(ren<0){
                    ren = n-1;
                }
                if(col==n){
                    col=0;
                }
            }
            return matrizMagica(matriz, n, num+1, ren, col);
        }
    }
    
    //            if(ren<0){
//                //matriz[n-1][col]=num;
//                return matrizMagica(matriz, n, num+1, n-1, col);
//            }else if(col>n){
//                //matriz[ren][0]=num;
//                return matrizMagica(matriz, n, num+1, ren, 0);
//            }else if(num%n == 0){
//                //matriz[ren+1][col]=num;
//                return matrizMagica(matriz, n, num+1, ren+1, col);
//            }else{
//                //matriz[ren][col]=num;
//                return matrizMagica(matriz, n, num+1, ren-1, col+1);
//            }
    public static int[][] cuadroMagico(int n){
        if(n%2!=1 || n<=0){
            throw new RuntimeException();
        }
        return cuadroMagico(n, new int[n][n], 0, n/2, 1);
    }
    
    private static int[][] cuadroMagico(int n, int[][] matriz, int ren, int col, int num){
        matriz[ren][col]=num;
        if(num == n*n){
            return matriz;
        }else{
            return cuadroMagico(n, matriz, nextRen(ren, n, num), nextCol(col,n,num), num+1);
        }
    }
    
    private static int nextRen(int ren, int n, int numAct){
        if(numAct%n ==0){
            return ren+1;
        }else if(ren!=0){
            return ren-1;
        }else{
            return n-1;
        }
    }
    
    private static int nextCol(int col, int n, int numAct){
        if(numAct%n==0){
            return col;
        }else if(col!=n-1){
            return col+1;
        }else{
            return 0;
        }
    }
}
