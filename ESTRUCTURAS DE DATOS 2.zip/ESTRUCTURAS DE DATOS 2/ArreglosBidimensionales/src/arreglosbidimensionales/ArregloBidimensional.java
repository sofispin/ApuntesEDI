/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arreglosbidimensionales;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 *
 * @author SOFIA
 */
public class ArregloBidimensional {

    private double[][] matriz;
    private int totRen, totCol;
    private final int MAX = 20;

    public ArregloBidimensional() {
        matriz = new double[MAX][MAX];
        totRen = 0;
        totCol = 0;
    }

    public int getTotRen() {
        return totRen;
    }

    public int getTotCol() {
        return totCol;
    }
   
    
    public boolean llenaMatriz(String nomArch) {
        boolean resp;
        try {
            File file = new File(nomArch);
            Scanner leeArch = new Scanner(file);
            int i, j;
            totRen = leeArch.nextInt();
            totCol = leeArch.nextInt();
            for (i = 0; i < totRen; i++) {
                for (j = 0; i < totCol; j++) {
                    matriz[i][j] = leeArch.nextDouble();
                }
            }
            resp = true;
            leeArch.close();
        } catch (FileNotFoundException ex) {
            resp = false;
        }
        return resp;
    }

    //Suma solo de cierto renglon
    /*public double sumaMatrizReng(int j, ArregloBidimensional[][] mat) {
        double suma=0;
        return sumaMatrizReng(j, 0, mat, suma);
    }

    private double sumaMatrizReng(int j, int i, ArregloBidimensional[][] mat, double suma) {
        if (i < this.totCol) {
            suma= suma + matriz[j][i];
            return sumaMatrizReng(j,i+1,mat,suma);
        }else{
            return 0;
        }
    }
    
    public double sumaMatrizCol() {
        double suma=0;
        return sumaMatrizCol(0, 0, suma);
    }

    private double sumaMatrizCol(int j, int i,double suma) {
        if (j < this.totRen) {
            suma= suma + matriz[j][i];
            return sumaMatrizCol(j+1,i,suma);
        }else{
            return 0;
        }
    }
    
    //Suma de toda la Matriz por columnas en un solo numero
    public double sumaMatrizColumna() {
        double suma=0;
        if(totRen>0 && totCol>0){
            return sumaMatrizColumna(0, 0, suma);
        }
            return suma;
    }

    private double sumaMatrizColumna(int ren, int col,double suma) {
        if (ren==totRen-1 && col==totCol-1) {
            return matriz[ren][col]+suma;
        }else if(col! = totCol-1){
            suma= suma + matriz[ren][col];
            return sumaMatrizCol(ren +1,col,suma);
        }else{
            suma=suma+matriz[ren][col];
            return sumaMatrizColumna(0,col+1,suma);
        }
    }
    
    */
    
    
    private double sumaPorRenglon(int ren, int col){
        if(ren == totRen-1 && col==totCol-1){
            return matriz[ren][col];
        }else if(col!=totCol-1){
            return matriz[ren][col]+sumaPorRenglon(ren,col+1);
        }else{
            return matriz[ren][col]+sumaPorRenglon(ren+1,0);
        }
    }
    
    public double sumaPorRenglon(){
        double suma;
        if(totRen>0 && totCol>0){
           return sumaPorRenglon(0,0); 
        }else{
            suma=0;
        }
        return suma;
    }
    
    private double sumaDiagonal(int indice){
        if(indice==totRen-1 && indice==totCol-1){
            return matriz[indice][indice];
        }else{
            return matriz[indice][indice]+sumaDiagonal(indice+1);
        }
    }
    
    public double sumaDiagonal(){
        if(totRen>0 && totCol>0 && totRen == totCol){
           return sumaDiagonal(0); 
        }else{
            return 0;
        }
    }   
    
    @Override
    public String toString(){
        StringBuilder str = new StringBuilder();
        int ren=0;
        return toString(matriz, ren, str);
    }
    
    private String toString(double[][] arr, int ren, StringBuilder str){
        if(ren<totRen){
            for(int col=0;col<totCol;col++){
                str.append(matriz[ren][col]).append(" ");
            }
            str.append("\n");
            return toString(arr,ren+1,str);
        }else{
            return str.toString();
        }
    }
    
    public double[][] sumaMatrices(double[][] arr, int col, int ren){
        double[][] aux= new double[totCol][totRen];
        if(totCol>0 && totRen>0 && totRen==ren && totCol==col){
            sumaMatrices(arr,0,0, aux);
            return aux; //No se pone aqui si regresa un double[][], se pone el return en la linea anterior. 
        }else{
            return arr;
        }
    }
    
    private void sumaMatrices(double[][] arr, int ren, int col, double[][] aux){
        if(ren<totRen){
            if(col<totCol){
                aux[ren][col]=matriz[ren][col] + arr[ren][col];
                sumaMatrices(arr,ren,col+1,aux); //return 
            } else{
                sumaMatrices(arr,ren+1,col,aux);//return si regresa double[][]
            }
        }
        /*Se pone esto si se regresa un double[][]
        }else{
            return aux;
        }*/
    }
    
    public double[][] multiplicacionMatrices(double[][] arr, int ren, int col){
        if(totCol>0 && totRen> 0 && totCol==ren){
            double[][] resul = new double[totRen][totCol];
            return multiplicacionMatrices(arr,0,0,resul);
        }else{
            return arr;
        }
    }
    
    private double[][] multiplicacionMatrices(double[][] arr, int ren, int col, double[][] resul){
        for(int i=0;i<totCol;i++){
            resul[ren][col]+= matriz[ren][i]*arr[i][col];
        }
        if(col<totCol-1){
            return multiplicacionMatrices(arr,ren,col+1,resul);
        }else if(ren<totRen-1){
            return multiplicacionMatrices(arr,ren+1,0,resul);
        }else{
            return resul;
        }
    }
    
    //Como recorrer una matriz
//    for(int i=0; i<arr.length; i++){
//        for(int j=0; j<arr[0].length; j++){
//            
//        }
//    }
    
    
}
