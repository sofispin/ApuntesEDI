/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javadoc;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author SOFIA
 */
public class RectanguloTest {
    
    public RectanguloTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of getBase method, of class Rectangulo.
     */
    @Test
    public void testGetBase() {
        System.out.println("getBase");
        Rectangulo instance = null;
        double expResult = 0.0;
        double result = instance.getBase();
        assertEquals(expResult, result, 0.0);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getAltura method, of class Rectangulo.
     */
    @Test
    public void testGetAltura() {
        System.out.println("getAltura");
        Rectangulo instance = null;
        double expResult = 0.0;
        double result = instance.getAltura();
        assertEquals(expResult, result, 0.0);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of toString method, of class Rectangulo.
     */
    @Test
    public void testToString() {
        System.out.println("toString");
        Rectangulo instance = null;
        String expResult = "";
        String result = instance.toString();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of equals method, of class Rectangulo.
     */
    @Test
    public void testEquals() {
        System.out.println("equals");
        Object obj = null;
        Rectangulo instance = null;
        boolean expResult = false;
        boolean result = instance.equals(obj);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of area method, of class Rectangulo.
     */
    @Test
    public void testArea() {
        System.out.println("area");
        Rectangulo instance = null;
        double expResult = 0.0;
        double result = instance.area();
        assertEquals(expResult, result, 0.0);
        /*// TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    */
    }

    /**
     * Test of perimetro method, of class Rectangulo.
     */
    @Test
    public void testPerimetro() {
        System.out.println("perimetro");
        Rectangulo instance = null;
        double expResult = 0.0;
        double result = instance.perimetro();
        assertEquals(expResult, result, 0.0);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
