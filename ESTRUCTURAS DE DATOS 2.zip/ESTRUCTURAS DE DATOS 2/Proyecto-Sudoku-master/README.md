# Proyecto-Sudoku

Segundo proyecto parcial - Estructuras de Datos

Descripción del algoritmo:
1. Al iniciarse el programa, se inicializan todas las estructuras de soporte. Como las matrices y conjuntos
2. Al modificar el valor de un cuadro en UI, un método se encarga de guardar su nombre, y buscar a su correspondiente en la matriz principal
3. Se llama a un metodo para que actualice valores con los indices del objeto modificado.
