 /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author AESS
 */
public class MetodosCalc {
    

    public boolean signosCheck(String cadena){ 
        boolean resp=true;
        boolean prim=false, sec=false;
        String[] arre=cadena.split("\\s");
        int i=1;
        int x=0;
        int c=arre.length-1;
        if((arre[x].equals("+") || arre[x].equals("-") || arre[x].equals("*") || arre[x].equals("/") ||
                        arre[x].equals("^")) || (arre[c].equals("+") || arre[c].equals("-") || 
                arre[c].equals("*") || arre[c].equals("/") || arre[c].equals("^")))
            resp=false;
        else{
            while(i<arre.length && !prim && !sec){
                if(arre[x].equals("+") || arre[x].equals("-") || arre[x].equals("*") || arre[x].equals("/") ||
                        arre[x].equals("^") )
                    prim=true;
                if(arre[i].equals("+") || arre[i].equals("-") || arre[i].equals("*") || arre[i].equals("/") ||
                        arre[i].equals("^") )
                    sec=true;
                if(prim==false || sec==false){
                    prim=false;
                    sec=false;
                }
                i++;
                x++;
            }
            if(i<arre.length)
                resp=false;
        }
        return resp;
        
    }
    
    public boolean parentesisCheck(String cadena){
        PilaA<String> pila = new PilaA();
        String[] arre=cadena.split("\\s");
        int i=0;
        int a=0,b=0;
        String temp;
        boolean resp=false,aux=true;
        while(i<arre.length && aux){
            if(arre[i].equals("(")){
                pila.push("(");
                temp="(";
                a=i;
            }
            else if(arre[i].equals(")")){
                if(a==i-1){
                    aux=false;
                }
                else if(!pila.isEmpty() && pila.peek().equals("("))
                    pila.pop();
                else
                    aux=false;
            }
            i++;
        }
        if(pila.isEmpty() && aux)
            resp=true;
        return resp;
        
    }

     public String InfijaPosfija(String cadena){
        String resp="";
        String[] arre=cadena.split("\\s");
        int i=0;
        int pot=0;
        PilaA<String> signos=new PilaA();
        PilaA<String> posfija=new PilaA();
        while(i<arre.length){
            switch(arre[i]){
                case"(": 
                    signos.push(arre[i]);
                    break;
                case")": 
                    while(!signos.isEmpty() && !signos.peek().equals("(")){
                       
                        posfija.push(signos.pop());  
                    }
                    signos.pop();
                    break;
                case"^":
                    signos.push(arre[i]);
                    pot++;
                    break;
                case"*":
                    signos.push(arre[i]);
                    break;
                case"/":
                    signos.push(arre[i]);
                    break;
                case"+":
                    signos.push(arre[i]);
                    break;
                case"-":
                    signos.push(arre[i]);
                    break;
                default:
                    posfija.push(arre[i]);
                    if(pot!=0){
                        posfija.push(signos.pop());
                        pot--;
                    }
                    break;
                    
        }
            i++;
            
        }
        while(!signos.isEmpty())
            posfija.push(signos.pop());
        while(!posfija.isEmpty())
            signos.push(posfija.pop());
        while(!signos.isEmpty())
            resp= resp+signos.pop()+" ";
        return resp;
    }
   
   public double evaluaEx(String cadena){
       double resp=0.0;
       double aux1,aux2;
       String[] arre=cadena.split("\\s");
       PilaA<String> ecuacion=new PilaA();
       PilaA<String> ecuacion1=new PilaA();
       for(int i=0;i<arre.length;i++)
           ecuacion.push(arre[i]);
       while(!ecuacion.isEmpty()){
           
           ecuacion1.push(ecuacion.pop());
       }
       while(!ecuacion1.isEmpty()){
           if(!ecuacion1.peek().equals("+") && !ecuacion1.peek().equals("-") && !ecuacion1.peek().equals("*") &&
                   !ecuacion1.peek().equals("/") && !ecuacion1.peek().equals("^")){
              ecuacion.push(ecuacion1.pop());
               
           }
   
           else{
               aux1=Double.parseDouble(ecuacion.pop());
               
               aux2=Double.parseDouble(ecuacion.pop());
               
                switch(ecuacion1.peek()){
                    
                    case "+":
                        resp=aux1+aux2;
                        ecuacion.push(resp+"");
                        break;
                    case "-":
                        resp=aux2-aux1;
                        ecuacion.push(resp+"");
                        break;
                     case "*":
                        resp=aux1*aux2;
                        ecuacion.push(resp+"");
                        break;
                     case "/":
                        resp=aux2/aux1;
                        ecuacion.push(resp+"");
                        break;
                     default:
                        resp=Math.pow(aux2, aux1);
                        ecuacion.push(resp+"");
                        break;
                }
                ecuacion1.pop();
           }
           
       }
       resp=Double.parseDouble(ecuacion.pop());
       return resp;
   }
}
