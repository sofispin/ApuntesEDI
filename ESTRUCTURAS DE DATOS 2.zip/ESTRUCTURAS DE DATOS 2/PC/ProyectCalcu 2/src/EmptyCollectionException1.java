/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author AESS
 */
public class EmptyCollectionException1 extends RuntimeException{
    public EmptyCollectionException1(){
        super("Collección vacía");
    }
    public EmptyCollectionException1(String mensaje){
        super(mensaje);
    }
    
}
