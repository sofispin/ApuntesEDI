/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author AESS
 */
public class Pruebas {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        MetodosCalc p= new MetodosCalc();
        String c="( ( ) 3 + ( 5 * 2 ) - 1 / 1 )";
        String c1="3 + ( 5 * 2 ) ^ 2 / 2";
        String c2="1 + 2 + 3";
        System.out.println(p.InfijaPosfija(c1));
        System.out.println(p.signosCheck(c1));
        System.out.println(p.evaluaEx(p.InfijaPosfija(c1)));
        System.out.println(p.parentesisCheck(c1));
        
    }
    
}
