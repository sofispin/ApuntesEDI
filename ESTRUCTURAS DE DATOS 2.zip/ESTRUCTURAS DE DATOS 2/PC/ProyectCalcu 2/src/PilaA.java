/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author AESS
 */
public class PilaA<T> implements PilaADT<T> {
    private T[] pila;
    private int tope;
    private final int MAX = 20;
    
    public PilaA(){
        pila= (T[]) new Object[MAX];
        tope = -1; //pila vacía
    }
    
    public PilaA(int max){ //para decidir yo de qué tamaño quiero mi pila
        pila = (T[]) new Object [max];
        tope = -1;
        
    }
    public boolean isEmpty(){
        return tope ==-1;
    }
    public void push(T dato){
        if(tope==pila.length-1) //checa si la pila está llena es length-1 porque tope empieza en -1
            expande();
        tope++;
        pila[tope] = dato;
    }
    public void expande(){
        T[] nuevo = (T[]) new Object[pila.length*2]; //crea una pila del doble del tamaño de la original
        for(int i=0; i<=tope;i++)
            nuevo[i] = pila[i]; //copia cada elemento de la pila viejita a la pila nueva que es del doble del tamaño, hasta el tope, dejándome mas espacio para apilar más cosas
        pila = nuevo;
    }
    public T pop(){
        T resultado; //no es necesario darle un valor inicial
        if(isEmpty())
            resultado = null;
        else{
            resultado = pila[tope];
            //pila[tope] = null;
            tope--;
        } 
        return resultado;
    }
    public T pop2(){
        if(isEmpty()){
            throw new EmptyCollectionException1("Pila Vacía");
        }else{
            T resultado = pila[tope];
            tope--;
            return resultado;
        }
            
    }
    public T peek(){
        T resultado;
        if(isEmpty())
            resultado = null;
        else
            resultado = pila[tope];
        return resultado;
    }
    
}
