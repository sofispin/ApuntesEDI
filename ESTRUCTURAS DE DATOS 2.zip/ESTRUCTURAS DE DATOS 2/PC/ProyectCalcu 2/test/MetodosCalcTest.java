/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author ESPINOLAC
 */
public class MetodosCalcTest {
    
    public MetodosCalcTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    @Test
    public void testSignosCheck() {
        System.out.println("signosCheck");
        String cadena = "3 + ( 5 * 2 ) ^ 2 / 2";
        MetodosCalc instance = new MetodosCalc();
        boolean expResult = true;
        boolean result = instance.signosCheck(cadena);
        assertEquals(expResult, result);
        
    }

    @Test
    public void testParentesisCheck() {
        System.out.println("parentesisCheck");
        String cadena = "3 + ( 5 * 2 ) ^ 2 / 2";
        MetodosCalc instance = new MetodosCalc();
        boolean expResult = true;
        boolean result = instance.parentesisCheck(cadena);
        assertEquals(expResult, result);
        
    }

    @Test
    public void testInfijaPosfija() {
        System.out.println("InfijaPosfija");
        String cadena = "3 + ( 5 * 2 ) ^ 2 / 2";
        MetodosCalc instance = new MetodosCalc();
        String expResult = "3 5 2 * 2 ^ 2 / + ";
        String result = instance.InfijaPosfija(cadena);
        assertEquals(expResult, result);
        
    }
    @Test
    public void testEvaluaEx() {
        System.out.println("evaluaEx");
        String cadena = "56+78*-";
        MetodosCalc instance = new MetodosCalc();
        double expResult = -45;
        double result = instance.evaluaEx(cadena);
        assertEquals(expResult, result, -45);
        
    }
    
}
