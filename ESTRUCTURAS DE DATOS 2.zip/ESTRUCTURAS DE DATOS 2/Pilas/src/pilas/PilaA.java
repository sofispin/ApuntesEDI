/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pilas;

import java.util.ArrayList;

/**
 *
 * @author SOFIA
 */
public class PilaA <T> implements PilaADT <T>{
    
    private T[] pila;
    private int tope;
    private final int MAX=20;

    public PilaA() {
        pila = (T[]) new Object[MAX];
        tope = -1; //Si lo hubiera iniciado en 0 parecería que tengo un elemento en la pila. Esto dice que mi pila esta vacia
    }
    
    public PilaA( int max){
        pila = (T[]) new Object[max];
        tope = -1;
    }
    
    public boolean isEmpty(){
        return tope == -1; //Compara y te da el resultado true o false. 
    }
    
    public void push(T dato){ 
        if(tope == pila.length-1){ //Pila.length te da el numero de casillas que tengo, por eso es length-1. 
            expandCapacity(); //Si ya pasaste de aquí si tienes espacio. 
        }   
        tope++; //Se sube el tope porque ya tienes mas espacio 
        pila[tope] = dato;
        }
    
    /*public T pop(){
        T resultado; 
        
        if(isEmpty()){
            resultado = null;
        } else{
            resultado = pila[tope]; //Aqui se pudo haber puesto pila[tope]=null; para que ya nada lo referencie. 
            tope--;
        }
        return resultado; 
    }*/
    
    public T pop(){
        T resultado;
        
        if(isEmpty()){
            throw new EmptyCollectionException("Pila Vacia");
        } //else{ ese else no es necesario porque si se cumple la excepcion me va a sacar del metodo completamente. 
        
        resultado = pila[tope]; //Aqui se pudo haber puesto pila[tope]=null; para que ya nada lo referencie. 
        tope--;
        //}
        return resultado;
    }
    
    public T peek(){ 
        if(isEmpty()){
            throw new EmptyCollectionException("Pila Vacia");
        }
        return pila[tope];
    }
    
    //Metodo ExpandCapacity();
    //Genera un arreglo nuevo del doble de tamaño, copia todo lo que tienes y luego le cambia la direccion a la pila original. 
    private void  expandCapacity(){
        T[] nuevo = (T[]) new Object[pila.length*2];
        for(int i=0; i<=tope; i++){
            nuevo[i]=pila[i];
        }
        pila = nuevo;
    }
    
    public boolean equals(PilaADT<T> pila1){
        if(pila1 ==null){
            throw new NullPointerException("Pila Vacia");
        }
        boolean iguales =false;
        int cont=0; 
        PilaADT <T> aux1= new PilaA();
        PilaADT <T> aux2= new PilaA();
        
        while(!isEmpty() && !pila1.isEmpty() && peek().equals(pila1.peek())){
            aux1.push(pop());
            aux2.push(pila1.pop());
            cont++;
        }
        if(isEmpty() && pila1.isEmpty()){
            iguales=true;
        }
        for(int i=0; i<cont; i++){
            this.push(aux1.pop());
            pila1.push(aux2.pop());
        }
        return iguales;
    }
    
   /* //Metodo para imprimir una pila (1er Parcial)
    // Returns a string representation of this stack.
  public String mprimirPila(PilaADT<T> pila) {
    StringBuilder str = new StringBuilder();
    int i=0;
    if(isEmpty()) {
        str.append("Pila is EMPTY");
    } else {
        while(!pila.isEmpty()){
            str.append(pila.pop().toString());
        }
    }
    return str.toString();
  }*/
    
    //Metodo para imprimir una pila (1er Parcial)
    public String imprimirPila() {
        if (isEmpty()) {
            throw new EmptyCollectionException("Pila Vacia");
        }
        StringBuilder str = new StringBuilder();
        PilaA <T> aux = new PilaA();
        while (!isEmpty()) {
            aux.push(pop());
        }
        while(!aux.isEmpty()){
            push(aux.pop());
            str.append(peek());
            str.append(" ");
        }
        //str.reverse();
        return str.toString();
    }
    
    
}
