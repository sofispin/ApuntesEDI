/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package poo2;

/**
 *
 * @author SOFIA
 */
public class POO2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here 
    
    //Problema 6

        // 1) Se crea la empresa y se dan de alta los empleados.
        Empresa e= new Empresa("Oracle","Calle 1-10","Albert");
        e.altaEmpleado("Rebeca", 15000,"Computación", "5405");
        e.altaEmpleado("Pablo",20000, "Mate","3160");
        e.altaEmpleado("Juan", 6000, "Ing. Ind.","8943");
        e.altaEmpleado("Paco",6000,10); 
        e.altaEmpleado("Hugo",7000,15); 
        e.altaEmpleado("Luis",7500,5);

        // 2) Genera reporte de los administartivos.
        System.out.println(e.reporteAdmons());   

        // 3) Aumento a un administrativo.
        if(e.aumentoAdmon(102, 0.10)) {
            System.out.println("Aumento exitoso");
            System.out.println(e.toString());
        }
        else  {
              System.out.println("El administrativo no existe");
        }   
        
        System.out.println(e.reporteOperarios(7));
        
        
        System.out.println("Reporte Operarios: \n" + e.reporteOperarios());
    
    }
    
}
