/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package poo2;

/**
 *
 * @author SOFIA
 */
public class Operario extends Empleado{
     private int horasExtra;

    public Operario() {
        super();
    }

    public Operario(String nombreEmpleado, double sueldoBase, int horasExtra) {
        super(nombreEmpleado, sueldoBase);
        this.horasExtra = horasExtra;
    }

    //Un constructor solo para la info de la clase
    /*public Operario(int horasExtra) {
        super();
        this.horasExtra = horasExtra;
    }
    */
    
    //Hash code es una función que genera una dirección para un objeto especifico
    //No se necesita
    
    public String toString(){
        StringBuilder str = new StringBuilder();
        str.append(super.toString());
        str.append("Horas Extra: " + horasExtra + "\n");
        
        return str.toString();
    }
    
    
    public double calculaSalario(double prestac, double deduc){
        return this.getSueldoBase()*(1 + prestac-deduc);
   }
    
    public double calculaSalario(double prestac, double deduc, double precioHE){
        return calculaSalario(prestac, deduc) + (horasExtra*precioHE);
    }
    
}
