/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pruebasegundoexamen;

import java.util.Iterator;

/**
 *
 * @author SOFIA
 */
public class PruebaSegundoExamen {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

    }

    public static boolean sonIguales(int arre1[][], int ren1, int col1, int arre2[][], int ren2, int col2) {
        if (arre1 == null || arre2 == null) {
            throw new NullPointerException();
        }
        if (ren1 > 0 && col1 > 0 && ren2 > 0 && col2 > 0) {
            int ren = 0, col = 0;
            if (ren1 == ren2 && col1 == col2) {
                return sonIguales(arre1, ren1, col1, arre2, 0, 0, true);
            } else {
                return false;
            }
        } else {
            throw new NullPointerException(); //Aqui es EmptyCollectionException pero no la hice
        }
    }

    private static boolean sonIguales(int arre1[][], int ren1, int col1, int arre2[][], int ren, int col, boolean resp) {
        if (resp == false) {
            return resp;
        } else if (ren == ren1 - 1 && col == col1 - 1) {
            return arre1[ren][col] == arre2[ren][col];
        } else if (col != col1 - 1) {
            resp = arre1[ren][col] == arre2[ren][col];
            return sonIguales(arre1, ren1, col1, arre2, ren, col + 1, resp);
        } else {
            resp = arre1[ren][col] == arre2[ren][col];
            return sonIguales(arre1, ren1, col1, arre2, ren + 1, col, resp);
        }
    }

    //Mas eficiente
    private static boolean sonIguales2(int arre1[][], int ren1, int col1, int arre2[][], int ren, int col) {
        if (arre1[ren][col] == arre2[ren][col]) {
            if (ren == ren1 - 1 && col == col1 - 1) {
                return arre1[ren][col] == arre2[ren][col]; //return true;
            } else if (col != col1 - 1) {
                return sonIguales(arre1, ren1, col1, arre2, ren, col + 1);
            } else {
                return sonIguales(arre1, ren1, col1, arre2, ren + 1, 0);
            }
        } else {
            return false;
        }
    }

    public boolean noHayVecinosIguales() {
        if (isEmpty()) {
            throw new EmptyCollectionException();
        }
        boolean resp = true;
        if (inicio == fin) {
            return resp;
        } else {
            ColaADT<T> aux = new ColaA();
            T elem = this.eliminar();
            while (!resp && !this.isEmpty()) {
                if (elem.equals(this.consultaPrimero())) {
                    resp = false;
                } else {
                    aux.insertar(elem);
                    elem = this.eliminar();
                }
            }
            aux.insertar(elem);
            while (!isEmpty()) {
                aux.insertar(this.eliminar());
            }
            while (!aux.isEmpty()) {
                this.insertar(aux.eliminar());
            }
        }
        return resp;
    }

    public static boolean analizaDeportivos(ConjuntoADT<Auto> cA, int n) {
        if (n < 0) {
            int cont = 0;
            Iterator<Auto> it = cA.iterator();
            while (it.hasNext() && n > cont) {
                if (it.next().getVelocidades() >= 5) {
                    cont++;
                }
            }
            if (cont >= n) {
                return true;
            } else {
                return false;
            }
        } else {
            throw new NullPointerException();
        }
    }

}
