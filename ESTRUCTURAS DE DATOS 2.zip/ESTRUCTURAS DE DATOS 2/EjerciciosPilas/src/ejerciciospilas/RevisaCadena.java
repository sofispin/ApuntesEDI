/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejerciciospilas;
import pilas.*;
/**
 *
 * @author SOFIA
 */
public class RevisaCadena {
    private String expresion;
    
    //Constructores
    public RevisaCadena() {
        expresion = "";
    }

    public RevisaCadena(String expresion) {
        this.expresion = expresion;
    }
            
    public boolean revisaBalanceoParentesis(){
        boolean balanceados= true;
        PilaA <Character> pila = new PilaA();
        int i=0;
        int n= expresion.length(); 
        
        while(i<n && balanceados){
            if(expresion.charAt(i) == '('){
                pila.push(expresion.charAt(i));
            } else{
                if (expresion.charAt(i) == ')'){
                    try{
                        pila.pop(); //Si pasa por el try es que no es nulo. 
                    } catch (EmptyCollectionException e){
                        balanceados = false; 
                    }
                }
            }
            i++;
        }
        
        return pila.isEmpty() && balanceados; //true && false = false. 
    }
    
}
