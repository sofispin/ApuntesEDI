

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejerciciospilas;

import java.util.ArrayList;
import pilas.*;

/**
 *
 * @author SOFIA
 */
public class EjerciciosPilas {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        //Esta mal
        //RevisaCadena cad = new RevisaCadena("((326 + 38))");
        //System.out.println(cad.revisaBalanceoParentesis());
        System.out.println(invertirCadena("Hola"));

        PilaA<String> pila = new PilaA(50);
        pila.push("h");
        pila.push("o");
        pila.push("l");
        pila.push("a");
        pila.imprimirPila();
        System.out.println(numeroElementos(pila));

        PilaA<String> pila2 = new PilaA(50);
        pila2.push("c");
        pila2.push("a");
        pila2.push("s");
        pila2.push("a");
        //System.out.println(inviertePila(pila2));
        inviertePila(pila2);
        System.out.println(pila2.imprimirPila());

        PilaA<String> pila3 = new PilaA(50);
        pila3.push("c");
        pila3.push("a");
        pila3.push("s");
        pila3.push("a");
        pila3.push("b");
        quitarRepetidos(pila3);
        System.out.println(pila3.imprimirPila());

        //System.out.println(contiene(pila2, pila3));
        //System.out.println(imprimirPila(pila2));
        //System.out.println(mismaPila(pila3, pila2));
        PilaA<Object> pilaE = new PilaA();
        pilaE.push('a');
        pilaE.push(17);
        pilaE.push('b');
        pilaE.push(21);
        pilaE.push("hola");
        pilaE.push('c');
        pilaE.push(7);
        pilaE.push(15);
        pilaE.push('g');
        pilaE.push("loco");

        System.out.println("PILA ORIGINAL" + " \n");
        System.out.println((pilaE.imprimirPila()));
        PilaA<Object> ejer = ejercicio1(pilaE);
        System.out.println("PILA final" + " \n");
        System.out.println(ejer.imprimirPila());
    }

    //Problema 13
    public static String invertirCadena(String cadena) {
        PilaA<Character> pila = new PilaA(cadena.length());
        StringBuilder str = new StringBuilder();

        for (int i = 0; i < cadena.length(); i++) {
            pila.push(cadena.charAt(i));
        }

        while (!pila.isEmpty()) {
            str.append(pila.pop());
        }
        return str.toString();
    }

    //Problema 14 Dice cuantos elementos tiene tu pila.
    public static <T> int numeroElementos(PilaA<T> pila) {
        if (pila.isEmpty()) {
            throw new EmptyCollectionException("Pila Vacia");
        }
        int cont = 0;
        PilaA<T> aux = new PilaA();

        while (!pila.isEmpty()) {
            aux.push(pila.pop());
            cont++;
        }

        while (!pila.isEmpty()) {
            pila.push(aux.pop());
        }
        return cont;
    }

    //Problema 16
    //Invertir los elementos de una pila
    public static <T> void inviertePila(PilaADT<T> pila) {
        /*if(pila.isEmpty()){
            throw new EmptyCollectionException("Pila Vacia");
        }*/
        ArrayList<T> aux = new ArrayList();
        //int i=0;

        /*if(pila!=null){
            while(!pila.isEmpty()){
                aux.add(i, pila.pop());
                i++;
            }
        }*/
        //O pudo ser
        if (pila != null) {
            while (!pila.isEmpty()) {
                aux.add(pila.pop());
            }
            for (int i = 0; i < aux.size(); i++) {
                pila.push(aux.get(i));
            }
        }
        //Esto te la regresa a la original. 
        /*while(!pila.isEmpty()){
            pila.push((T) aux.get(i));
            i--;
        }*/
        //return aux.toString();
    }

    /* //Metodo para imprimir una pila (1er Parcial)
    public static <T> String imprimirPila(PilaA<T> pila) {
        if (pila.isEmpty()) {
            throw new EmptyCollectionException("Pila Vacia");
        }
        StringBuilder str = new StringBuilder();
        PilaA <T> aux = new PilaA();
        while (!pila.isEmpty()) {
            str.append(pila.peek());
            aux.push(pila.pop());
        }
        while(!aux.isEmpty()){
            pila.push(aux.pop());
        }
        //str.reverse();
        return str.toString();
    }*/
    //Problema 17
    //Quita los elementos repetidos de una pila
    public static <T> void quitarRepetidos(PilaADT<T> pila) {
        if (pila.isEmpty()) {
            throw new EmptyCollectionException("Pila Vacia");
        }
        PilaA aux = new PilaA();
        aux.push(pila.pop());
        while (!pila.isEmpty()) {
            if (aux.peek().equals(pila.peek())) {
                pila.pop();
            } else {
                aux.push(pila.pop());
            }
        }
        while (!aux.isEmpty()) {
            pila.push((T) aux.pop());
        }
    }

    //Problema 15
    /*public static <T> boolean contiene(PilaADT<T> pila1, PilaADT<T> pila2) {
        if (pila1 == null || pila2 == null) {
            throw new NullPointerException();
        }

        ArrayList<T> aux1 = new ArrayList();
        PilaADT<T> aux2 = new PilaA();
        boolean res = true;

        while (!pila1.isEmpty()) {
            aux1.add(pila1.pop());
        }
        while (!pila2.isEmpty() && res) {
            aux2.push(pila2.pop());
            if (!aux1.contains(aux2.peek())) {
                res = false;
            }
        }
        while (!aux2.isEmpty()) {
            pila2.push(aux2.pop());
        }
        for (int i = aux1.size(); i > 0; i--) {
            pila1.push(aux1.get(i));
        }
        return res;
    }*/
    //Metodo para determinar si 2 pilas son iguales (mismo orden, numero de elementos y mismos elementos)
    //en la Clase Pila y un método estatico. O sea son dos. 
    //Si es estatico recibe dos pilas, en la clase pila es un equals y recibe una como parametro. 
    public static <T> boolean mismaPila(PilaADT<T> pila1, PilaADT<T> pila2) {
        if (pila1 == null || pila2 == null) {
            throw new NullPointerException("Pila Nula");
        }
        if (pila1.isEmpty() || pila2.isEmpty()) {
            throw new EmptyCollectionException("Pila Vacia");
        }
        boolean iguales = true;
        int cont;
        PilaADT<T> aux1 = new PilaA();
        PilaADT<T> aux2 = new PilaA();

        while (!pila1.isEmpty() && !pila2.isEmpty() && iguales) {
            if (aux1.peek().equals(aux2.peek())) {
                aux1.push(pila1.pop());
                aux2.push(pila2.pop());
            } else {
                iguales = false;
            }
        }
        //Si una de las dos pilas no se acabo
        if (!pila2.isEmpty() || !pila2.isEmpty()) {
            iguales = false;
        }

        while (!aux1.isEmpty()) {
            pila1.push(aux1.pop());
        }
        while (!aux2.isEmpty()) {
            pila2.push(aux2.pop());
        }
        return iguales;
    }

    // EJERCICIO
    //Pilas esta en el cuaderno 
    //Ejercicios
    public static <T> PilaA ejercicio1(PilaADT<T> pila) {
        PilaA<Object> aux = new PilaA();

        if (pila == null) {
            throw new NullPointerException();
        }
        if (pila.isEmpty()) {
            throw new EmptyCollectionException();
        }

        while (!pila.isEmpty()) {
            if (pila.peek() instanceof String) {
                String s = pila.pop() + "s";
                aux.push(s);
            } else if (pila.peek() instanceof Character) {
                Character c = (Character) pila.peek();
                switch (c) {
                    case 'b':
                        aux.push(pila.pop());
                        break;
                    case 'c':
                        pila.pop();
                        aux.push('a');
                        break;
                    case 'a':
                        pila.pop();
                        aux.push('g');
                        break;
                    default:
                        pila.pop();
                        break;
                }
            } else if (pila.peek() instanceof Integer) {
                if ((Integer) pila.peek() % 7 == 0) {
                    aux.push(pila.pop());
                } else {
                    pila.pop();
                }
            }
        }
        while (!aux.isEmpty()) {
            pila.push((T) aux.pop());
        }
        return (PilaA) pila;
    }

    public static <T> void intercambiaPorPares(PilaA<T> pila) {
        if (pila == null) {
            throw new NullPointerException();
        }
        if (pila.isEmpty()) {
            throw new EmptyCollectionException();
        }

        PilaADT<T> aux = new PilaA();
        double cont = 0;
        int i = 0;
        T elem1, elem2;

        while (!pila.isEmpty()) {
            aux.push(pila.pop());
            cont++;
        }

        if (cont > 1) {
            while (cont / 2 > i) {
                elem1 = aux.pop();
                elem2 = aux.pop();
                pila.push(elem2);
                pila.push(elem1);
                i++;
            }
        }
        while (!aux.isEmpty()) {
            pila.push(aux.pop());
        }
    }
}
