/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package listas;

/**
 *
 * @author SOFIA
 */
public class ListaOrd<T extends Comparable<T>> extends Lista<T> implements ListaOrdADT<T> {

    public ListaOrd() {
        super();
    }

    public boolean estaVacio() {
        return primero == null;
    }

    @Override
    public void agrega(T dato) {
        if (dato != null) {
            if (!estaVacio()) {
                if (dato.compareTo(primero.getDato()) < 0) {
                    Nodo<T> nuevo = new Nodo(dato);
                    nuevo.setDir(primero);
                    primero = nuevo;
                } else {
                    if (!primero.getDato().equals(dato)) {
                        if (primero.getDir() != null) {
                            agrega(dato, primero);
                        } else {
                            Nodo<T> nuevo = new Nodo(dato);
                            primero.setDir(nuevo);
                        }
                    }
                }
            } else {
                Nodo<T> nuevo = new Nodo(dato);
                primero = nuevo;
            }
        }
    }

    private void agrega(T dato, Nodo<T> aux) {
        if (aux.getDir() != null) {
            if (dato.compareTo(aux.getDir().getDato()) > 0) {
                agrega(dato, aux.getDir());
            } else {
                if (!dato.equals(aux.getDir().getDato())) {
                    Nodo<T> nuevo = new Nodo(dato);
                    nuevo.setDir(aux.getDir());
                    aux.setDir(nuevo);
                }
            }
        } else {
            Nodo<T> nuevo = new Nodo(dato);
            aux.setDir(nuevo);
        }
    }

    public boolean equals(Object otra) {
        if (otra == null || estaVacia() || ((ListaOrd)otra).estaVacio()) {
            throw new NullPointerException();
        }
        Nodo<T> aux1 = primero;
        Nodo<T> aux2 = ((ListaOrd)otra).primero;
        boolean iguales = true;
        while (aux1.getDir() != null && aux2.getDir() != null && iguales) {
            if (aux1.getDato().equals(aux2.getDato())) {
                aux1 = aux1.getDir();
                aux2 = aux2.getDir();
            } else {
                iguales = false;
            }
        }
        return iguales;
    }

}
