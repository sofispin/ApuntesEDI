/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package listas;

import java.util.Iterator;

/**
 *
 * @author SOFIA
 */
public class MateriaSemestre {
    private String nombreMateria;
    private String salon;
    private int semestreMat;
    private String maestro;
    private ListaOrdADT<Alumno> listaAlumnos;
    private ListaDesADT<Libro> listaLibros;

    public MateriaSemestre() {
        listaAlumnos = new ListaOrd();
        listaLibros = new ListaDes();
        
    }

    public MateriaSemestre(String nombreMateria, String salon, int semestreMat, String maestro) {
        this();
        this.nombreMateria = nombreMateria;
        this.salon = salon;
        this.semestreMat = semestreMat;
        this.maestro = maestro;
    }

    public String getNombreMateria() {
        return nombreMateria;
    }

    public String getSalon() {
        return salon;
    }

    public int getSemestreMat() {
        return semestreMat;
    }

    public String getMaestro() {
        return maestro;
    }
    
    @Override
    public String toString() {
        return "MateriaSemestre{" + "nombreMateria=" + nombreMateria + ", salon=" + salon + ", semestreMat=" + semestreMat + ", maestro=" + maestro + ", listaAlumnos=" + listaAlumnos + ", listaLibros=" + listaLibros + '}';
    }
    
    
    private boolean bajaAlumno(int claveUnica){
       Iterator<Alumno> it = listaAlumnos.iterator();
       Alumno al=it.next();
       boolean sePudo = false;
        while(it.hasNext()){
            if(al.getCu()==claveUnica){
                listaAlumnos.quita(al);
                sePudo = true;
            }
        }
        return sePudo;
    }
    
    private void altaAlumno(String nombre, String carrera, String semestre){
        Alumno al = new Alumno(nombre, carrera, semestre);
        listaAlumnos.agrega(al);
    }

    public void setSalon(String salon) {
        this.salon = salon;
    }
    
    private void altaLibro(String titulo, String autor, String materia){
        Libro li = new Libro(titulo, autor, materia);
        listaLibros.agregaInicio(li);
    }
    
    private boolean bajaLibro(String titulo){
       Iterator<Libro> it = listaLibros.iterator();
       Libro li=it.next();
       boolean sePudo = false;
        while(it.hasNext()){
            if(li.getAutor().equals(titulo)){
                listaLibros.quita(li);
                sePudo = true;
            }
        }
        return sePudo;
    }
    
    private String toString(int claveUnica){
       Iterator<Alumno> it = listaAlumnos.iterator();
       Alumno al=it.next();
       StringBuilder str = new StringBuilder();
       str = null;
        while(it.hasNext()){
            if(al.getCu()==claveUnica){
                str.append(al.getNombre() + ", ");
                str.append(al.getCarrera() + ", ");
                str.append(al.getSemestre());
            }
        }
        return str.toString();
    }
    
    
}
