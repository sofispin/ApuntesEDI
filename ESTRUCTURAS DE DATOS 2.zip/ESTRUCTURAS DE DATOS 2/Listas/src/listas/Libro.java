/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package listas;

/**
 *
 * @author SOFIA
 */
public class Libro {
    
    private String titulo;
    private String autor;
    private String materia;

    public Libro() {
    }

    public Libro(String titulo, String autor, String materia) {
        this.titulo = titulo;
        this.autor = autor;
        this.materia = materia;
    }

    public String getTitulo() {
        return titulo;
    }

    public String getAutor() {
        return autor;
    }

    public String getMateria() {
        return materia;
    }

    @Override
    public String toString() {
        return "Libro{" + "titulo=" + titulo + ", autor=" + autor + ", materia=" + materia + '}';
    }
    
}
