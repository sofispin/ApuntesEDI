/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package listas;

import java.util.Iterator;

/**
 *
 * @author SOFIA
 */
public class Club {
    private String nombreClub;
    private ListaOrd<Persona> listaSoc;

    public Club(String nombreClub) {
        this.nombreClub = nombreClub;
        listaSoc = new ListaOrd();
    }
    
    public void agregaSocios(String nombre, int edad){
        Persona pers = new Persona(nombre, edad);
        if(!listaSoc.contiene(pers)){
            listaSoc.agrega(pers);
        }
    }
    
    public Persona bajaSocio(int clave){
        Iterator<Persona> it = listaSoc.iterator();
        boolean ya= false;
        Persona pers=null;
        while(it.hasNext() && !ya){
            pers=it.next();
            if(pers.getClave() == clave){
                listaSoc.quita(pers);
                ya = true;
            }
        }
        return pers;
    }
    
    public void consultaDatos(int clave){
        Iterator <Persona> it = listaSoc.iterator();
        boolean ya = false;
        
        while(it.hasNext() && !ya){
            Persona pers = it.next();
            if(pers.getClave() == clave){
                System.out.println("Datos: " + pers.toString());
                ya=true;
            }
        }
    }
}
