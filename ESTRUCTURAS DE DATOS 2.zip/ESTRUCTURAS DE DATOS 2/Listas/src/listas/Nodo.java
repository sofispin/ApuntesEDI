/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package listas;

/**
 *
 * @author SOFIA
 */
public class Nodo <T> {
    //Estructura recursiva, se corta cuando llegas a un nodo que no apunta a nada
    
    private T dato;
    private Nodo <T> dir; //En mi casilla de nodo guardo mi dato y otro nodo(su direccion de memoria).
    
    public Nodo(){
        dato=null;
        dir = null;
    }
    
    public Nodo(T dato){
        this.dato = dato;
        this.dir = null;
    }

    public T getDato() {
        return dato;
    }

    public void setDato(T dato) {
        this.dato = dato;
    }

    public Nodo<T> getDir() {
        return dir;
    }

    public void setDir(Nodo<T> dir) {
        this.dir = dir;
    }

    public String toString() {
        return "Nodo:" + "dato=" + dato.toString();
    }
    
    
}
