/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package listas;

/**
 *
 * @author SOFIA
 */
public class Alumno implements Comparable<Alumno>{
    
    private String nombre;
    private String carrera;
    private String semestre;
    private int cu;
    private static int clave=100;

    public Alumno() {
        cu = clave++;
    }
    
    public Alumno(String nombre, String carrera, String semestre) {
        this();
        this.nombre = nombre;
        this.carrera = carrera;
        this.semestre = semestre;
    }

    public String getNombre() {
        return nombre;
    }

    public String getCarrera() {
        return carrera;
    }

    public String getSemestre() {
        return semestre;
    }

    public int getCu() {
        return cu;
    }

    @Override
    public String toString() {
        return "Alumno{" + "nombre=" + nombre + ", carrera=" + carrera + ", semestre=" + semestre + '}';
    }
    
    public int compareTo(Alumno al){
        return cu-al.getCu();
    }
}
