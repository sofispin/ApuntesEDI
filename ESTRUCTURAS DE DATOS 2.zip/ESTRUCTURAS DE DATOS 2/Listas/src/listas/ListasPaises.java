/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package listas;

import java.util.Iterator;

/**
 *
 * @author SOFIA
 */
public class ListasPaises {

    private ListaOrd<Pais> listaNorte;
    private ListaOrd<Pais> listaSur;
    private ListaOrd<Pais> listaCentro;

    private ListaOrd<Pais> listaContinente;

    public ListasPaises() {
        this.listaContinente = new ListaOrd();
    }

    //Super ineficiente
    public void agregaPais(String nombre, String lugar) {
        Pais pais = new Pais(nombre, lugar);
        if (lugar.equals("Norte")) {
            listaCentro.agrega(pais);
        } else if (lugar.equals("Sur")) {
            listaSur.agrega(pais);
        } else {
            listaCentro.agrega(pais);
        }
    }

    //Bueno, hay que hacer un metodo extra que ordene 2 listas: lo mismo pero con 2 listas. 
    public void formarContinenteEficiente() {
        if (listaNorte == null || listaSur == null || listaCentro == null) {
            throw new NullPointerException();
        }
        if (listaNorte.estaVacio() || listaSur.estaVacio() || listaCentro.estaVacio()) {
            throw new RuntimeException();
        }
        Iterator<Pais> it1 = listaNorte.iterator();
        Iterator<Pais> it2 = listaCentro.iterator();
        Iterator<Pais> it3 = listaSur.iterator();

        Pais aux1 = it1.next();
        Pais aux2 = it2.next();
        Pais aux3 = it3.next();

        boolean noHay1 = false;
        boolean noHay2 = false;
        boolean noHay3 = false;

        while ((it1.hasNext() || noHay1) && (it2.hasNext() || noHay2) && (it3.hasNext() || noHay3)) {
            if(!noHay1){
                aux1=it1.next();
                noHay1 = true;
            }
            if(!noHay2){
                aux2 = it2.next();
                noHay2 = true;
            }
            if(!noHay3){
                aux3 = it3.next();
                noHay3 = true;
            }
            
            if (aux1.compareTo(aux2) < 0) {
                if (aux1.compareTo(aux3) < 0) {
                    listaContinente.agrega(aux1);
                    noHay1 = true; //Solo me modifica el que hice, y solo va a checar esa. Dice la necesidad de volver a leer. 
                } else {
                    listaContinente.agrega(aux3);
                    noHay3 = true;
                }
            } else {
                if (aux2.compareTo(aux3) < 0) { //Aux2<aux3
                    listaContinente.agrega(aux2);
                    aux2 = it2.next();
                } else {
                    listaContinente.agrega(aux3);
                    aux3 = it3.next();
                }
            }
        }
    }
    
    private void agregaUnoDos(){
        Iterator<Pais> it1 = listaNorte.iterator();
        Iterator<Pais> it2 = listaCentro.iterator();

        Pais aux1 = it1.next();
        Pais aux2 = it2.next();

        boolean noHay1 = false;
        boolean noHay2 = false;

        while ((it1.hasNext() || noHay1) && (it2.hasNext() || noHay2)) {
            if(!noHay1){
                aux1=it1.next();
                noHay1 = true;
            }
            if(!noHay2){
                aux2 = it2.next();
                noHay2 = true;
            }
            
            if (aux1.compareTo(aux2) < 0) {
                listaContinente.agrega(aux1);
                noHay1=false;
            }
            
            if(aux2.compareTo(aux1)<0){
                listaContinente.agrega(aux2);
                noHay2 = false;
            }
        }
    }
    
    public void agregaUno(){
        Iterator<Pais> it2 = listaSur.iterator();
        while(it2.hasNext()){
            listaContinente.agrega(it2.next());
        }
        
    }
    

    public void formarContinente() {
        listaContinente = listaNorte;
        ListaOrd<Pais> aux1 = listaSur;
        ListaOrd<Pais> aux2 = listaCentro;
        while (!aux1.estaVacio()) {
            listaContinente.agrega(aux1.quitaPrim());
        }
        while (!aux2.estaVacio()) {
            listaContinente.agrega(aux2.quitaPrim());
        }

    }
}
