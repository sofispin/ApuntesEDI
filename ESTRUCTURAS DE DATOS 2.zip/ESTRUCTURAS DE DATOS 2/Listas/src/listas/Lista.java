/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package listas;

import java.util.Iterator;

/**
 *
 * @author SOFIA
 */
public abstract class Lista <T> implements ListaADT<T>{
    protected Nodo<T> primero;
    
    public Lista(){
        primero = null;
    }
    
    public Iterator <T> iterator(){
        return new IteradorEE(primero);
    }
    
    public boolean estaVacia(){
        return primero == null;
    }
    
    //Recursion usando iterador (NO TE DA ACCESO A LA ESTRUCTURA).
    public int calcTam(){
        return calcTam(iterator(), 0);
    }
    
    private int calcTam(Iterator <T> it, int cont){
        if(it.hasNext()){
            it.next();
            return calcTam(it,cont+1);
        }else{
            return cont;
        }
    }
    
    //Recursion usando un nodo
    public String toString(){
        return toString(new StringBuilder(), primero);
    }
    
    private String toString(StringBuilder str, Nodo<T> act){
        if(act == null){
            return str.toString();
        }else{
            str.append(act.getDato());
            str.append(" ");
            return toString(str, act.getDir());
        }
    }
    
    public T quitaPrim(){
        T res;
        if (estaVacia()) {
            res = null;
        } else {
            res = primero.getDato();
            Nodo<T> aux = primero;
            primero = primero.getDir();//Primero ahora es el siguiente. 
            aux.setDir(null);//Se rompe la relacion entre el que elimino y el resto de mis nodos. 
        }
        return res;
    }
    
    public T consultaPrim(){
        if(!estaVacia()){
            return primero.getDato();
        }else{
            return null;
        }
    }
    public T consultaUlt(){
        if(estaVacia()){
            throw new RuntimeException();
        }else if(primero.getDir() == null){
            return primero.getDato();
        }else{
            Nodo<T> aux = primero;
            while(aux.getDir().getDir()!=null){
                aux = aux.getDir();
            }
            return aux.getDato();
        }
    }
    
    public T quitaUlt(){
        T dato = null;
        if(primero == null){
            return dato; //Throw new NullPointerException();
        }else if(primero.getDir() == null){
            dato = primero.getDato();
            primero = null;
            return dato;
        }else{
            return quitaUlt(dato, primero);
        }
    }
    
    private T quitaUlt(T dato, Nodo<T> actual){
        if(actual.getDir().getDir() == null){
            dato = actual.getDir().getDato();
            actual.setDir(null);
            return dato;
        }else{
            return quitaUlt(dato, actual.getDir());
            
        }
    }
    
    public T quita(T dato){
        if(primero == null){
            throw new NullPointerException();
        }
        T resp = null;
        Nodo<T> aux = primero;
        if(primero.getDato().equals(dato)){
                resp = primero.getDato();
                if(primero.getDir() == null){
                   primero = null; 
                }else{
                    Nodo <T> res = aux.getDir();
                    aux.setDir(res.getDir());
                    primero = null;
                }
                
        }else{
             
             while(aux.getDir() != null){
                 if(aux.getDir().getDato().equals(dato)){
                     Nodo <T> res = aux.getDir();
                     resp = res.getDato();
                     aux.setDir(res.getDir());
                     res = null;
                 }else{
                     aux.setDir(aux.getDir());
                 }
             }
        }
        return resp;
    }
    
    public boolean contiene(T dato){
        return contiene(dato, primero);
    }

    private boolean contiene(T dato, Nodo<T> ap) {
        if (ap == null) {
            return false;
        } else {
            if (ap.getDato().equals(dato)) {
                return true;
            } else {
                return contiene(dato, ap.getDir());
            }
        }
    }
}
