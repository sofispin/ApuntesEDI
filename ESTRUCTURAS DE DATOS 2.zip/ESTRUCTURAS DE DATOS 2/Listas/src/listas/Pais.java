/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package listas;

/**
 *
 * @author SOFIA
 */
public class Pais implements Comparable<Pais>{
    private String nombre;
    private String lugar;

    public Pais() {
    }

    public Pais(String nombre, String lugar) {
        this.nombre = nombre;
        this.lugar = lugar;
    }

    public String getNombre() {
        return nombre;
    }

    public String getLugar() {
        return lugar;
    }
    
    public int compareTo(Pais dato){
        return nombre.compareTo(dato.getNombre());
    }
}
