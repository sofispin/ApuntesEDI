
 /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package listas;

import java.util.Iterator;

/**
 *
 * @author SOFIA
 */
public class ListaDes<T> extends Lista<T> implements ListaDesADT<T> {

    public ListaDes() {
    }

    public void agregaInicio(T dato) {
        Nodo<T> nuevo = new Nodo(dato);
        nuevo.setDir(primero);
        primero = nuevo;
    }

    public void agregaFinal(T dato) {
        Nodo<T> nuevo = new Nodo(dato);
        if (estaVacia()) {
            primero = nuevo;
        } else {
            Nodo<T> aux = primero;
            while (aux.getDir() != null) {
                aux = aux.getDir();
            }
            aux.setDir(nuevo);
        }
    }

    public boolean agregaAntesQue(T refer, T dato) {
        if (estaVacia() || refer == null || dato == null) {
            throw new NullPointerException();
        }
        boolean resp = false;
        Nodo<T> insert = new Nodo(dato);
        if (primero.getDato().equals(refer)) {
            insert.setDir(primero);
            primero = insert;
            resp = true;
        } else {
            Nodo<T> aux = primero;
            while (aux.getDir() != null && !aux.getDir().getDato().equals(refer)) {
                insert.setDir(aux.getDir());
                aux.setDir(insert);
                resp = true;
            }
        }
        return resp;
    }

    public boolean agregaDespuesQue(T refer, T dato) {
        if (estaVacia() || refer == null || dato == null) {
            throw new NullPointerException();
        }
        boolean resp = false;
        Nodo<T> insert = new Nodo(dato);
        Nodo<T> aux = primero;
        while (aux.getDir() != null && !aux.getDir().getDato().equals(refer)) {
            aux.setDir(insert.getDir());
            insert.setDir(aux);
            resp = true;
        }
        return resp;
    }
    
    public boolean esPalindromo(){
        if(this.estaVacia()){
            throw new RuntimeException();
        }
        StringBuilder str1 = new StringBuilder();
        StringBuilder str2 = new StringBuilder();
        Nodo<T> aux1= primero;
        while(aux1!=null){
            str1.append(aux1.getDato());
            aux1=aux1.getDir();
        }
        str2.append(str1.reverse());
        if(str1.equals(str2)){
            return true;
        }else{
            return false;
        }
    }
    
    public void invierteLista(){
        if(estaVacia()){
            throw new NullPointerException();
        }
        if(primero.getDir()!=null){
            Nodo<T> aux=primero;
            Nodo<T> aux2 = aux.getDir();
            Nodo<T> aux3;
            while(aux2!=null){
                aux3=aux2.getDir();
                aux2.setDir(aux);
                aux=aux2;
                aux2=aux3;
            }
            primero.setDir(null);
            primero = aux;
            
        }
    }
    
    public void invierteListaRec(){
        if(estaVacia()){
            throw new NullPointerException();
        }
        if(primero.getDir()!=null){
            invierteListaRec(primero, primero.getDir());
        }
    }
    
    private void invierteListaRec(Nodo<T> aux, Nodo<T> aux2){
        if(aux2==null){
            primero.setDir(null);
            primero=aux;
        }else{
            Nodo<T> aux3= aux2.getDir();
            aux2.setDir(aux);
            invierteListaRec(aux2,aux3);
        }
    }
    
    public void intercambiaPorPares(){
        if(estaVacia() || primero.getDir()==null){
            throw new NullPointerException();
        }
        if(primero.getDir().getDir()!= null){
            intercambiaPorPares(primero, null);
        }
    }
    
    private void intercambiaPorPares(Nodo<T> aux1, T aux2){
        if(aux1 != null){
            aux2 = aux1.getDato();
            if(aux1.getDir() != null){
                aux1.setDato(aux1.getDir().getDato());
                aux1.getDir().setDato(aux2);
                aux1 = aux1.getDir().getDir();
                intercambiaPorPares(aux1,aux2);
            }
        }
//        if(aux1!=null){
//            aux2=aux1.getDato();
//        }
    }
}
