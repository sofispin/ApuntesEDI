/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package listas;

import java.util.Iterator;

/**
 *
 * @author SOFIA
 */
public class Listas {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Club club = new Club("Hola");
        
        club.agregaSocios("Sofia", 20);
        club.agregaSocios("Hola", 23);
        club.bajaSocio(2);
        
        club.consultaDatos(2);
        
        //Prueba ejercicio sumaInversos
        ListaDesADT<Integer> lista1 = new ListaDes();
        ListaDesADT<Integer> lista2 = new ListaDes();
        
        lista1.agregaInicio(7);
        lista1.agregaFinal(1);
        lista1.agregaFinal(6);
        lista2.agregaInicio(6);
        lista2.agregaFinal(3);
        lista2.agregaFinal(9);
        
        System.out.println("Lista 1: "+ lista1.toString());
        System.out.println("Lista 2: "+ lista2.toString());
        System.out.println("Suma Listas: " + sumaInversos(lista1,lista2));
        System.out.println("Lista 1: "+ lista1.toString());
        System.out.println("Lista 2: "+ lista2.toString());
        
        System.out.println("Suma Recursivo: " + sumaInversosRec(lista1, lista2));
        
        System.out.println("Suma normal: " + suma(lista1,lista2));
        
        ListaDesADT<String> lista3 = new ListaDes();
        lista3.agregaInicio("A");
        lista3.agregaInicio("B");
        lista3.agregaFinal("A");
        System.out.println("Palindromos:" + lista3.esPalindromo());
        
        lista3.invierteListaRec();
        
        System.out.println("Invierte Lista: " + lista3);
        
        System.out.println("Promedio: " + (1.10625+0.8733+4.2+2.5));
    }
    
    public static int sumaInversos(ListaDesADT<Integer> lista1, ListaDesADT<Integer> lista2){
        if(lista1 == null || lista2 == null){
            throw new NullPointerException();
        }
        int suma=0;
        if(lista1.calcTam() == lista2.calcTam()){
            Iterator<Integer> it1 = lista1.iterator();
            int suma1=it1.next();
            Iterator<Integer> it2=lista2.iterator();
            int suma2=it2.next();
            int r=10;
            while(it1.hasNext() && it2.hasNext()){
                suma1= suma1+(it1.next()*r);
                System.out.println("Suma 1: " + suma1);
                suma2= suma2+(it2.next()*r);
                System.out.println("Suma 2: " + suma2);
                r = r*r;
            }
             suma = suma1 + suma2;   
        }
        return suma;
    }
    
    public static int sumaInversosRec(ListaDesADT<Integer> lista1, ListaDesADT<Integer> lista2){
        if(lista1 == null || lista2 == null){
            throw new NullPointerException();
        }
        int suma=0;
        if(lista1.calcTam() == lista2.calcTam()){                                                   
            int r=1;
            suma= sumaInversosRec(lista1.iterator(),lista2.iterator(), suma, r);
        }
        return suma;
    }
    
    private static int sumaInversosRec(Iterator<Integer> it1, Iterator<Integer> it2, int suma, int r){
        if(it1.hasNext() && it2.hasNext()){
            suma = suma + it1.next()*r + it2.next()*r;
            return sumaInversosRec(it1, it2, suma, r*10);
        }else{
            return suma;
        }
    }
    
    public static int suma(ListaDesADT<Integer> lista1, ListaDesADT<Integer> lista2){
        if(lista1 == null || lista2 == null){
            throw new NullPointerException();
        }
        int suma=0;
        if(lista1.calcTam() == lista2.calcTam()){
            StringBuilder str1 = new StringBuilder();
            StringBuilder str2 = new StringBuilder();
            Iterator<Integer> it1 = lista1.iterator();
            
            Iterator<Integer> it2=lista2.iterator();
            while(it1.hasNext() && it2.hasNext()){
                str1.append(it1.next());
                str2.append(it2.next());
            }
            suma = Integer.parseInt(str1.toString())+Integer.parseInt(str2.toString());
        }
        return suma;
    }
    
    public static int sumaRec(ListaDesADT<Integer> lista1, ListaDesADT<Integer> lista2){
        if(lista1 == null || lista2 == null){
            throw new NullPointerException();
        }
        int suma=0;
        if(lista1.calcTam() == lista2.calcTam()){
            suma = sumaRec(new StringBuilder(), new StringBuilder(), lista1.iterator(), lista2.iterator());
        }
        return suma;
    }
    
    private static int sumaRec(StringBuilder str1, StringBuilder str2, Iterator<Integer> it1, Iterator<Integer> it2){
        if(it1.hasNext() && it2.hasNext()){
            str1.append(it1.next());
            str2.append(it2.next());
            return sumaRec(str1, str2, it1, it2);
        }else{
            return Integer.parseInt(str1.toString())+Integer.parseInt(str2.toString());
        }
    }
    
}
