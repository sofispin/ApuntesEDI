/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package problema10;

/**
 *
 * @author SOFIA
 */
public class DeVolteo extends Camion{
    
    private double capacidadTon;

    public DeVolteo() {
    }

    public DeVolteo( String marca, String numMotor, String placas, double capacidadTon) {
        super(marca, numMotor, placas);
        this.capacidadTon = capacidadTon;
    }

    @Override
    public String toString() {
        return "DeVolteo{" + super.toString() + "capacidadTon=" + capacidadTon + '}';
    }

    public void setCapacidadTon(double capacidadTon) {
        this.capacidadTon = capacidadTon;
    }
    
    
}
