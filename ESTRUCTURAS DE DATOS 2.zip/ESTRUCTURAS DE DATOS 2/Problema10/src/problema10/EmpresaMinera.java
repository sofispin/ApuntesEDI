/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package problema10;

import java.io.*;
import java.util.Scanner;


/**
 *
 * @author SOFIA
 */
public class EmpresaMinera implements Serializable{
    
    private String nombreEmp;
    private Camion[] camiones;
    private int totalCam;
    private final int MAX=50;

    public EmpresaMinera() {
        camiones=new Camion[50];
        totalCam=0;
    }

    public EmpresaMinera(String nombreEmp) {
        this();
        this.nombreEmp = nombreEmp;
    }
    
    public boolean altaCamion(String marca, String numMotor, String placas, double capacidadTon) {
        
        DeVolteo c= new DeVolteo(marca, numMotor, placas, capacidadTon);
        boolean resp = false;
        // Da de alta si hay espacio en el arreglo
        if( totalCam < MAX) {
            camiones[totalCam] = c;
            totalCam++;
            resp = true;
        }
        return resp;
    }
    
    public boolean altaCamion(String marca, String numMotor, String placas, int totalPasaj) {
        
        DePasajeros c= new DePasajeros(marca, numMotor, placas, totalPasaj);
        boolean resp = false;
        // Da de alta si hay espacio en el arreglo
        if( totalCam < MAX) {
            camiones[totalCam] = c;
            totalCam++;
            resp = true;
        }
        return resp;
    }
    
    //Carga de datos por medio de un archivo. 
    public boolean cargaDatos(String nomArch){
        boolean resultado;
        
        try{
            FileInputStream file = new FileInputStream(nomArch);
            ObjectInputStream lee = new ObjectInputStream(file);
            Object dato;
            dato=lee.readObject();
            while(dato!=null && totalCam<camiones.length){
                camiones[totalCam]=(Camion)dato;
                totalCam++;
                dato=lee.readObject();
            }
            lee.close();
            resultado = true;
        } catch(Exception e){
            resultado =false;
        }
        return resultado;
    }
    
    public boolean respaldaDatos(String nomArch){
        boolean resultado;
        
        try{
            FileOutputStream file = new FileOutputStream(nomArch);
            ObjectOutputStream escribe = new ObjectOutputStream(file);
            Object dato;
            for(int i=0; i<totalCam;i++){
                escribe.writeObject(camiones[i]);   
            }
            escribe.close();
            resultado = true;
        } catch(Exception e){
            resultado =false;
        }
        return resultado;
    }
    
    public boolean capturaInicial(String nomArch){
        boolean resultado;
        try{
            Scanner lee= new Scanner(System.in);
            FileOutputStream file = new FileOutputStream(nomArch);
            ObjectOutputStream escribe = new ObjectOutputStream(file);
            Camion camion;
            int n,i,tipo,pasaj,j;
            String motor, placa, marca;
            double capac;
            do{
                System.out.println("¿Cuántos camiones?");
                n=lee.nextInt();
            }while(n<1||n>camiones.length);
            
            for(i=1; i<=n;i++){
                System.out.println("Datos del camion");
                motor=lee.nextLine();
                marca=lee.nextLine();
                placa=lee.nextLine();
                System.out.println("Tipo de camión: 1 Vol, 2 Pas");
                tipo=lee.nextInt();
                if(tipo==1){
                    System.out.println("Capacidad");
                    capac=lee.nextDouble();
                    camion= new DeVolteo(marca, motor, placa, capac);
                }else{
                    System.out.println("Pasajeros");
                    pasaj=lee.nextInt();
                    camion=new DePasajeros(marca, motor, placa, pasaj);
                }
                 escribe.writeObject(camion);
            }
          resultado=true;
          escribe.close();
        }catch(Exception e){
            resultado=false;
        }
        return resultado;
    }
    
    
    //METODOS QUE TE PIDEN DEL EJERCICIO. 
    
    public String reporteCamiones() {
        StringBuilder strb;
        strb = new StringBuilder();
        for(int i=0; i<totalCam;i++){
            strb.append(camiones[i].toString());
            strb.append("\n");
        }
        return strb.toString();
    }
    
    public boolean actualizarCap(String placa, int nuevaCap){
        boolean sePudo=false;
        
        for(int i=0; i<totalCam;i++){
            if(camiones[i] instanceof DeVolteo && camiones[i].getPlacas().equals(placa)){
                ((DeVolteo)camiones[i]).setCapacidadTon(nuevaCap);
                sePudo=true;
            }
        }
        return sePudo;
    }
    
    
    
}
