/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package problema10;

/**
 *
 * @author SOFIA
 */
public class Problema10 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        EmpresaMinera empresa= new EmpresaMinera();
        
        empresa.cargaDatos("Archivo");
        
        //Opción a)
        if(empresa.capturaInicial("Camiones")){
            if(empresa.cargaDatos("Camiones")){
                System.out.println(empresa.reporteCamiones());
                empresa.altaCamion( "Mercedes", "hsd83w", "A36duj", 827);
                empresa.altaCamion("Mercedes", "hsd83w", "A36duj", 9387.28);
                
                empresa.respaldaDatos("Camiones 2");
            }
        }
        
        
    }
    
}
