
package primerparcialed_septiembre2018;

/**
 *
 * @author sguardatb
 */
public class Yogurt extends ProductoLacteo{
    private int ingredAdicionales;

    public Yogurt() {
    }

    public Yogurt(int ingredAdicionales, String marca, double precio, double presentacion, int mesVencimiento) {
        super(marca, precio, presentacion, mesVencimiento);
        this.ingredAdicionales = ingredAdicionales;
    }

    public int getIngredAdicionales() {
        return ingredAdicionales;
    }

    @Override
    public String toString() {
        return super.toString() + "\nYogurt con " + ingredAdicionales + " ingredientes adicionales";
    }
    
}
