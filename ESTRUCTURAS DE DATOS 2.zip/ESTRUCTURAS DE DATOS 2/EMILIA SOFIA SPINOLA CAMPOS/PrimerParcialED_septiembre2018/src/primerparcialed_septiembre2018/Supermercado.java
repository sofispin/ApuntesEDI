package primerparcialed_septiembre2018;

/**
 *
 * @author EMILIA SOFIA SPINOLA CAMPOS
 */
public class Supermercado {

    private String nombre, dirección;
    private ProductoLacteo[] inventario;
    private int total;
    private final int MAX = 50;

    public Supermercado() {
        inventario = new ProductoLacteo[MAX];
        total = 0;
    }

    public Supermercado(String nombre, String dirección) {
        this();
        this.nombre = nombre;
        this.dirección = dirección;
    }

    public boolean altaProducto(String tipo, String marca, double precio, double presentacion, int mesVencimiento) {
        boolean respuesta;

        if (total < inventario.length) {
            respuesta = true;
            inventario[total] = new Queso(tipo, marca, precio, presentacion, mesVencimiento);
            total++;
        } else {
            respuesta = false;
        }
        return respuesta;
    }

    public boolean altaProducto(int ingredAdicionales, String marca, double precio, double presentacion, int mesVencimiento) {
        boolean respuesta;

        if (total < inventario.length) {
            respuesta = true;
            inventario[total] = new Yogurt(ingredAdicionales, marca, precio, presentacion, mesVencimiento);
            total++;
        } else {
            respuesta = false;
        }
        return respuesta;
    }

    /**
     * Solución ejercicio 3 del primer parcial
     *
     * @param cantKilos
     * @param tipoQueso
     * @param mes
     * @return 
     */
    public boolean determinaKilosQuesoVencenMes(double cantKilos, String tipoQueso, int mes) {
        boolean existen = false;
        double sumaKilos = 0;
        int i=0;
        
        if(mes<=12 && mes >= 1 && cantKilos >0)
        while(i<total && sumaKilos<cantKilos) {
            if (this.inventario[i] instanceof Queso) {
                if (((Queso) this.inventario[i]).getTipo().equals(tipoQueso) && this.inventario[i].getMesVencimiento() < mes) {
                    sumaKilos += ((ProductoLacteo) this.inventario[i]).getPresentación();
                }
            }
        }
        if (sumaKilos >= cantKilos) {
            existen = true;
        }

        return existen;
    }
    
    
    /*public boolean determinaKilosQuesoVencenMes(double cantKilos, String tipoQueso, int mes) {
        boolean existen = true;
        int i=0;
        while(i<this.total && existen) {
            if (this.inventario[i] instanceof Queso) {
                if (!((Queso) this.inventario[i]).getTipo().equals(tipoQueso) && this.inventario[i].getMesVencimiento() > mes && ((ProductoLacteo) this.inventario[i]).getPresentación()< cantKilos) {
                    existen = false;
                }
            }
            i++;
        }
        return existen;
    }*/
    
    
}
