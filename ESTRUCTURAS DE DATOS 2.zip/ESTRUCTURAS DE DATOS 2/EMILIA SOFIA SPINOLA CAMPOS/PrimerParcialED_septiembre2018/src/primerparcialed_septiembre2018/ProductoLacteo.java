
package primerparcialed_septiembre2018;

/**
 *
 * @author sguardatb
 */
public class ProductoLacteo {
    private String marca;
    private double precio;
    private double presentacion; // Dada en gramos
    private int mesVencimiento; // 1-enero, 2-febrero, etc.

    public ProductoLacteo() {
    }

    public ProductoLacteo(String marca, double precio, double presentacion, int mesVencimiento) {
        this.marca = marca;
        this.precio = precio;
        this.presentacion = presentacion;
        this.mesVencimiento = mesVencimiento;
    }

    public int getMesVencimiento() {
        return mesVencimiento;
    }
    
    public double getPresentación() {
        return presentacion;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    @Override
    public String toString() {
        return "\n Marca= " + marca + ", precio= " + precio + ", presentación= " + presentacion + ", mes de vencimiento= " + mesVencimiento;
    }   
}
