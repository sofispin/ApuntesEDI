package primerparcialed_septiembre2018;

/**
 * Interface para definir el comportamiento de una Pila.
 * @author EMILIA SOFIA SPINOLA CAMPOS
 */



public interface PilaADT <T>{
    public T pop();
    public T peek();
    public boolean isEmpty();
    public void push(T dato);
    public boolean multiPop(int n);
}
