package primerparcialed_septiembre2018;

/**
 * Clase Pila que implementa la interface PilaADT. Es genérica. El pop y el
 * peek, en caso de que la pila esté vacía, lanzan una excepción del tipo
 * EmptyCollectionException definida para tal fin.
 *
 * @author EMILIA SOFIA SPINOLA CAMPOS
 */
public class PilaArreglo<T> implements PilaADT<T> {

    private T colec[];
    private int tope;
    private final int MAX = 10;

    public PilaArreglo() {
        colec = (T[]) (new Object[MAX]);
        tope = -1;
    }

    public boolean isEmpty() {
        return tope == -1;
    }

    public T peek() {
        if (isEmpty()) {
            throw new EmptyCollectionException("Pila Vacía");
        }
        return colec[tope];
    }

    public T pop() {
        if (isEmpty()) {
            throw new EmptyCollectionException("Pila Vacía");
        }
        T dato = colec[tope];
        tope--;
        return dato;
    }

    public void push(T dato) {
        if (colec.length == tope + 1) {
            expandCapacity();
        }
        tope++;
        colec[tope] = dato;
    }

    private void expandCapacity() {
        T nuevo[] = (T[]) (new Object[colec.length * 2]);
        int i;

        for (i = 0; i <= tope; i++) {
            nuevo[i] = colec[i];
        }
        colec = nuevo;
    }

    public boolean multiPop(int n) {
        if (this.isEmpty()) {
            throw new EmptyCollectionException("Pila Vacia");
        }
        if(n<=0){
            throw new RuntimeException();
        }
        
        PilaADT<T> aux = new PilaArreglo();
        boolean sePudo = true;
        T elem;
        try {
            for (int i = 0; i < n; i++) {
                elem = this.pop();
                aux.push(elem);
            }
        } catch (Exception e) {
            sePudo = false;
            while (!aux.isEmpty()) {
                this.push( aux.pop());
            }
        }
        return sePudo;
    }
    
    public boolean multiPop2(int n) {
        if(n<=0){
            throw new RuntimeException();
        }
        boolean band;
        if(tope+1>=n){
            tope=tope-n;
            band=true;
        }else{
            band=false;
        }
        return band;
    }

    public String toString() {
        if (this.isEmpty()) {
            throw new EmptyCollectionException("Pila Vacia");
        }
        StringBuilder str = new StringBuilder();
        PilaADT aux = new PilaArreglo();

        while (!this.isEmpty()) {
            aux.push(this.pop());
        }

        while (!aux.isEmpty()) {
            str.append(aux.peek() + "\n");
            this.push((T) aux.pop());
        }
        return str.toString();
    }
}
