package primerparcialed_septiembre2018;

/**
 *
 * @author EMILIA SOFIA SPINOLA CAMPOS
 */
public class PrimerParcialED_septiembre2018 {

    /**
     * Solución del ejercicio 1 del primer parcial
     *
     * @param numero
     * @return
     */
    public static int convierteBinario(int numero) {
        if (2 > numero || numero > 1000) {
            throw new RuntimeException();
        }
        PilaADT aux = new PilaArreglo();
        String binario = "";
        int num;
        int resultado;

        while (numero > 0) {
            num = numero % 2;
            aux.push(num);
            numero = numero / 2;
        }

        while (!aux.isEmpty()) {
            binario = binario + aux.pop();
        }
        try {
            resultado = Integer.parseInt(binario);
        } catch (Exception e) {
            System.out.println("Numero incorrecto. Resultado igual a -1:");
            resultado = -1;
        }
        return resultado;
    }

    public static int convierteBinario2(int numero) {
        if (numero < 2 || numero > 1000) {
            throw new RuntimeException();
        }
        int binario=0, contador = 0;
        PilaADT<Integer> pila = new PilaArreglo();
        while (numero >= 2) {
            pila.push(numero % 2);
            contador++;
            numero = numero / 2;
        }
        while(!pila.isEmpty()){
            binario+= pila.pop()*Math.pow(10, --contador);
        }
        
        //otra forma
        /*if (numero < 2 || numero > 1000) {
            throw new RuntimeException();
        }
        int res=0;
        PilaADT<Boolean> aux = new PilaArreglo();
        while (numero >0) {
            aux.push((numero%2)==1);
            numero = numero / 2;
        }
        while(!aux.isEmpty()){
            res*=10;
            if(aux.pop()){
                res+=1;
            }
        }*/
        
        return binario;
    }

    public static <T> String imprime(PilaADT<T> pila) {
        if (pila.isEmpty()) {
            throw new EmptyCollectionException("Pila Vacia");
        }
        StringBuilder str = new StringBuilder();
        PilaADT aux = new PilaArreglo();

        while (!pila.isEmpty()) {
            aux.push(pila.pop());
        }

        while (!aux.isEmpty()) {
            str.append(aux.peek() + "\n");
            pila.push((T) aux.pop());
        }
        return str.toString();
    }

    public static void main(String[] args) {

        /* Escribe los casos de prueba que consideres conveniente
        para asegurarte de que tus soluciones funcionan correctamente
        y cubren todas las restricciones y especificaciones dadas, en cada 
        ejercicio.
         */
        //Prueba imprimir pila
        PilaADT<String> pila1 = new PilaArreglo();
        pila1.push("c");
        pila1.push("a");
        pila1.push("s");
        pila1.push("a");

        System.out.println(imprime(pila1));

        System.out.println(convierteBinario(8));
        System.out.println(convierteBinario(7));
        System.out.println(convierteBinario(2));
        System.out.println(convierteBinario(0));
        System.out.println(convierteBinario(1000));
        System.out.println(convierteBinario(2000));

        //Ejercicio 2
        System.out.println("Sacar 5 elementos:" + pila1.multiPop(5));
        System.out.println("Pila: " + "\n" + imprime(pila1));
        System.out.println("Sacar 5 elementos:" + pila1.multiPop(2));
        System.out.println("Pila: " + "\n" + imprime(pila1));

        //Ejercicio 3
        //hay 2 metodos porque no sabia si me pedian si la suma de los kilos de todos o si todas las presentaciones debian de ser de mas de esos kilos
        Supermercado sup = new Supermercado();
        sup.altaProducto("Queso", "hola", 400, 1, 12);
        sup.altaProducto("gruyere", "hola", 123, 4, 3);
        System.out.println(sup.determinaKilosQuesoVencenMes(3, "gruyere", 12));

    }

}
