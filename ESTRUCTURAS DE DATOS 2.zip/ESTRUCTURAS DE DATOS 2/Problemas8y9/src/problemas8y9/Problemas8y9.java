/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package problemas8y9;

import java.util.ArrayList;
import java.util.*;

/**
 *
 * @author SOFIA
 */
public class Problemas8y9 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        ArrayList <FigGeom> arrFig = new ArrayList<>();
        
        Circulo c1 = new Circulo(2);
        Circulo c2 = new Circulo(5);
        Cuadrado cu1 = new Cuadrado(3);
        Cuadrado cu2 = new Cuadrado(4);
        Rectangulo r1= new Rectangulo(2,1);
        Triangulo t1= new Triangulo(2,2);
        
        arrFig.add(c1);
        arrFig.add(cu1);
        arrFig.add(r1);
        arrFig.add(t1);
        arrFig.add(c2);
        arrFig.add(cu2);
        
        calcularTodoFigs(arrFig);
        calcularTodoFigs2(arrFig);
        
        }
    
    
    public static void calcularTodoFigs(ArrayList<FigGeom> arr){
            double area=0;
            double circulo=-1;
            Circulo circ = null;
            int cuadrados=0;
            
            for (int i=0; i<arr.size();i++){
                area += arr.get(i).calculaArea(); //No se castea porque todos los elementos tiene calcular Area. 
            }
            
            for (int i =0; i<arr.size();i++){
                if(arr.get(i) instanceof Circulo){
                    if (circulo < arr.get(i).calculaArea()){
                        circulo = arr.get(i).calculaArea();
                        circ = (Circulo)arr.get(i);
                    }
                }
            }
            for(int i=0; i<arr.size(); i++){
                if((arr.get(i).getClass().getSimpleName().equals("Cuadrado"))){
                //if((arr.get(i) instanceof Cuadrado)){
                    cuadrados ++;
                }
            }
            for(int i=0; i<arr.size(); i++){
                if(arr.get(i).getClass().getSimpleName().equals("Triangulo")){
                //if(arr.get(i) instanceof Triangulo){
                      arr.remove(i);
                }
            }
            System.out.println("Area total: " + area);
            System.out.println("Circulo mas grande: " + circ);
            System.out.println("Total cuadrados: " + cuadrados);
            System.out.println("Cadena final: " + arr.toString());
    }
    
    public static void calcularTodoFigs2(ArrayList<FigGeom> arr){
            double area=0;
            double circulo=-1;
            Circulo circ = null;
            int cuadrados=0;
            
            for (int i=0; i<arr.size();i++){
                area += arr.get(i).calculaArea(); //No se castea porque todos los elementos tiene calcular Area.
                
                //Esta mal
                if(arr.get(i) instanceof Circulo && circulo < ((Circulo)arr.get(i)).getRadio()){
                        circulo = arr.get(i).calculaArea();
                        circ = (Circulo)arr.get(i);
                }
                
                if((arr.get(i).getClass().getSimpleName().equals("Cuadrado"))){
                //if((arr.get(i) instanceof Cuadrado)){
                    cuadrados ++;
                }
                
                if(arr.get(i).getClass().getSimpleName().equals("Triangulo")){
                //if(arr.get(i) instanceof Triangulo){
                      arr.remove(i);
                }
               

            }
            
            System.out.println("Area total: " + area);
            System.out.println("Circulo mas grande: " + circ);
            System.out.println("Total cuadrados: " + cuadrados);
            System.out.println("Cadena final: " + arr.toString());
    }
    
    
    //Otras formas:
    
    public static String encuentraCircMax(ArrayList arr){
        double max=-1; 
        int index=0;
        String resultado;
        
        for(int i=0; i<arr.size(); i++){
            if(arr.get(i) instanceof Circulo && ((Circulo)arr.get(i)).getRadio()>max){
                max = ((Circulo)arr.get(i)).getRadio();
                index =i;
            }
        }
        if (max>0){
            resultado=arr.get(index).toString();
        } else{
            resultado=null;
        }
        
        /*
        //o con try-catch
       
        try{
            if(((Circulo)arr.get(i)).getRadio()>circulo){
                circ=((Circulo)arr.get(i));
            }
        }catch(Exception e){
            e.getMessage();
        }
        */
        
        return resultado;
    }
    
    /*
    Recorre izquierdo
    private void recorreIzq(int pos){
        for(int i=pos; i<arr.size()-1; i++){
        arr.get(i)=arr.get(i+1);
        }
    }
    
    public int eliminarEquilateros(){
        int cont=0;
        int i=0;
        
        //NOOOO se usa el for porque si hubiera 2 triangulos juntos se saltaría uno de los dos.
        for (int i=0; i<totalElem;i++){
            if(arr[i] instanceof Triangulo && ((Triangulo)arr[i].isEquilatero()){
                recorreIzq(i);
                totalElem--;
                cont++;
                arr(totalElem]=null;
            }
        }
    
        //SIII Se usa un while
        while(i< totalElem){
            if(arr[i] instanceof Triangulo && ((Triangulo)arr[i].isEquilatero()){
                recorreIzq(i);
                totalElem--;
                cont++;
                arr(totalElem]=null;
            }else { //Solo si no quito nada me muevo a la siguiente posición, porque si no se queda un a posicion que no uso. 
                i++;
            }
        }
    return cont;
    }
    */
    
}
