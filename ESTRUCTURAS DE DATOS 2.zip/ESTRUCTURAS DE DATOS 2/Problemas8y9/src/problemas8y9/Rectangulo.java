/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package problemas8y9;

/**
 *
 * @author SOFIA
 */
public class Rectangulo extends Cuadrilatero{
    
    private double lado2;

    public Rectangulo() {
    }

    public Rectangulo( double lado, double lado2) {
        super(lado);
        this.lado2 = lado2;
    }

    public double getLado2() {
        return lado2;
    }

    public void setLado2(double lado2) {
        this.lado2 = lado2;
    }

    @Override
    public String toString() {
        return "Rectangulo{" + super.toString() + "lado2=" + lado2 + '}';
    }
    
    //METODOS QUE PIDE LA CLASE ABSTRACTA CUADRILATERO:
    public double calculaArea(){
        return super.lado*lado2;
    }
    
    public double calculaPerim(){
        return 2*(super.lado+lado2);
    }
    
    public double calculaArea(double lado, double lado2){
        return lado*lado2;
    }
    
    public double calculaPerim(double lado, double lado2){
        return 2*(lado+lado2);
    }
}
