/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package problemas8y9;

/**
 *
 * @author SOFIA
 */
public class Triangulo implements FigGeom{
    
    private double base;
    private double altura;

    protected Triangulo() {
        this.altura=2;
        this.base=4;
    }

    public Triangulo(int base, int altura) {
        this.base = base;
        this.altura = altura;
    }

    public double getBase() {
        return base;
    }

    public void setBase(int base) {
        this.base = base;
    }

    public double getAltura() {
        return altura;
    }

    public void setAltura(int altura) {
        this.altura = altura;
    }

    @Override
    public String toString() {
        return "Triangulo{" + "base=" + base + ", altura=" + altura + '}';
    }
    
    //METODOS QUE PIDE LA INTERFACE FIGURA GEOMETRICA:
    
    public double calculaArea(double base, double altura){
        return (base*altura)/2;
    }
    
    public double calculaPerim(double base){
        return 3*(base);
    }
    
    public double calculaArea(){
        return (base*altura)/2;
    }
    
    public double calculaPerim(){
        return 3*(base);
    }
}
