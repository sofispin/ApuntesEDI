/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package problemas8y9;

/**
 *
 * @author SOFIA
 */
public class Circulo implements FigGeom{
    
    private double radio;

    public Circulo() {
        this.radio=1;
    }

    public Circulo(double radio) {
        this.radio = radio;
    }

    public double getRadio() {
        return radio;
    }

    public void setRadio(int radio) {
        this.radio = radio;
    }

    @Override
    public String toString() {
        return "Circulo{" + "radio=" + radio + '}';
    }
    
    //METODOS QUE PIDE LA INTERFACE FIGURA GEOMETRICA:
    
    public double calculaArea(){
        return (Math.PI*radio*radio);
    }
    
    public double calculaPerim(){
        return (2*Math.PI*radio);
    }
    
    public double calculaArea(double radio){
        return (Math.PI*radio*radio);
    }
    
    public double calculaPerim(double radio){
        return (2*Math.PI*radio);
    }
    
}
