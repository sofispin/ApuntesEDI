/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package problemas8y9;

/**
 *
 * @author SOFIA
 */
public abstract class Cuadrilatero implements FigGeom{

    protected double lado;
    
    public Cuadrilatero() {
        this.lado=1;
    }

    public Cuadrilatero(double lado) {
        this.lado = lado;
    }
    
    public double getLado() {
        return lado;
    }

    public void setLado(double lado) {
        this.lado = lado;
    }

    @Override
    public String toString() {
        return "Cuadrilatero{" + "lado=" + lado + '}';
    }
    
    public abstract double calculaArea();
    
    public abstract double calculaPerim();
    
    /*
    Pude haber puesto de atributos 4 lados, y hacer constructor vacio y con los 4 lados
    Además de ya programar los 2 metodos: area y perimetro:
    
    p double calculaArea(){
        return lad01*lado3;
    }
    
    p double calculaPerimetro(){
        return lado1+lado2+..*lado4;
    }
    */
}
