/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package problemas8y9;

/**
 *
 * @author SOFIA
 */
public class Cuadrado extends Cuadrilatero{

    public Cuadrado() {
        super();
    }

    public Cuadrado(double lado) {
        super(lado);
    }
    
    //METODOS QUE PIDE LA CALSE ABSTRACTA CUADRILATERO:
    
    public double calculaPerim(){
        return super.lado*4;
    }
    
    public double calculaArea(){
        return super.lado*super.lado;
    }
    
    public double calculaPerim(double lado){
        return lado*4;
    }
    
    public double calculaArea(double lado){
        return lado*lado;
    }
}
