/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package recursion;

/**
 *
 * @author SOFIA
 */
public class Recursion {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        String[] arr= {"a","b","c"};
        Double[] arr1={1.0,2.0,3.0};
        
        System.out.println(factorial(3));
        
        System.out.println(sumaArreglo(arr1,3));
        
        imprimeArrDI(arr,3);
        imprimeArrID(arr,3,0);
        
        System.out.println("Particiones: " + particiones(4));

    }

    
    //Este problema es mas eficiente hacerla con un for
    public static int factorial(int n) {
        if (n == 1 || n == 0) { //Estado Base
            return 1;
        } else {
            return n * factorial(n - 1); //Estado Recursivo + operacion que acerca a estado base
        }
    }
    
    public static double sumaArreglo(Double[] arr, int n){
        if(n<0 || arr.length==0){
            throw new NullPointerException();
        }
        if(n==0){ //EB
            return 0;
        }else{
            return arr[n-1] + sumaArreglo(arr,n-1);//ER
        }
    }
    
    public static void imprimeArrDI(String[] arr, int n){
        if(n>0){
            System.out.println(arr[n-1]);
            imprimeArrDI(arr, n-1);
        }
    }
    
    public static void imprimeArrID(String[] arr, int n, int c){
        if(c!=n && c>=0){
            System.out.println(arr[c]);
            imprimeArrID(arr, n, c+1);
        }
    }
    
    public static void imprimeArrID(String[] arr, int n){
        if(n>0){
            imprimeArrID(arr, n-1);//Usando la pila del arreglo. 
            System.out.println(arr[n-1]);
        }
    }
    
    public static int particiones(int n){
        return particiones(n,n);
    }
    
    private static int particiones(int n, int m){
        if(n==1 || m ==1){
            return 1;
        }else if(m<n){
            return particiones(m,m);
        }else if(m==n){
            return 1 + particiones(m,m-1);
        }else{
            return particiones(m,n-1) + particiones(m-n,n);
        }
    }
    
    //TORRES DE HANOI   
   public static void imprimeTorresHanoi(int n, String orig, String dest, String aux){
       if(n==1){
           System.out.println("Mover 1 disco de " + orig + " a " + dest);
       }else{
           imprimeTorresHanoi(n-1, orig,aux, dest);
           System.out.println("Mover 1 disco de " + orig + " a " + dest);
           imprimeTorresHanoi(n-1, aux,dest, orig);
       }
   }
   
   public static int reverse(int n){
       if(n<10){
           return n;
       }else{
           return reverse(n,0);
       }
   }
   
   private static int reverse(int n, int dig){
       if(n>0){
           dig = (dig*10)+n%10;
           return reverse(n/10,dig);
       }else{
           return dig;
       }
   }
   
   private static int binario(int n){
       if(n<0){
           return -1;
       }else{
           return binario(n,0);
       }
   }
   
   private static int binario(int n, int bin){
       if(n==0){
           return bin;
       }else{
           return (binario(n/2,bin)*10)+n%2;
       }
   }
   
   private static int cuentaImpares(int[] arr, int n){
       if(n>0){
           if(arr[n-1]%2 != 0){
               return cuentaImpares(arr,n-1)+1;
           }else{
               return cuentaImpares(arr,n-1);
           }
       }else{
           return n;
       }
   }
   
   public static int convierteNum(int num, int base){
       if(num<0 || base<2 || base>=10){
           return -1; 
       }else{
           StringBuilder str = new StringBuilder();
           return Integer.parseInt(convierteNum(num,base,str));
       }
   }
   
   private static String convierteNum(int num, int base, StringBuilder str){
       if(num == 0){ 
           return str.toString();
       }else{
           return convierteNum(num/base, base, str.append(num%base));
       }
   }
   
   public static int convierteNum2(int num, int base){
       if(num<0 || base<2 || base>=10){
           return -1; 
       }else{
           return convierteNum21(num,base);
       }
   }
   
   private static int convierteNum21(int num, int base){
       if(num <= 1){ //num==0
           return num;
       }else{
           return (convierteNum(num/base, base)*10)+(num%base);//Si multiplico el mod por 10, me da el numero al reves
       }
   }
}
