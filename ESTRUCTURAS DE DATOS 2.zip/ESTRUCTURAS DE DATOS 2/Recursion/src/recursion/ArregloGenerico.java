/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package recursion;

/**
 *
 * @author SOFIA
 */
public class ArregloGenerico <T extends Comparable <T>>{
    
    private T[] arr;
    private int total;
    private final int MAX=10;

    public ArregloGenerico() {
        this.total=0;
        arr = (T[]) new Comparable[MAX];
    }

    public ArregloGenerico(int max) {
        this.total=0;
        arr = (T[]) new Comparable[max];
    }
    
    //Ejercicio 24
    public int busquedaSecuencial(T dato, int i){
        if(arr[i].compareTo(dato) != 0){
            return busquedaSecuencial(dato, i+1);
        }else{
            return -1;
        }
    }
    
    public int busquedaBinaria(T dato){
        return busquedaBinaria(dato, 0, total-1, (total-1)/2);
    }
    
    public int busquedaBinaria(T dato, int inicio, int fin, int mitad) {
        int medio;
        if (inicio <= fin && !arr[mitad].equals(dato)) {
            if(dato.compareTo(arr[mitad])<0){
                return busquedaBinaria(dato, inicio, mitad-1, (inicio+mitad-1)/2);
            }else{
                return busquedaBinaria(dato, mitad+1,fin,(mitad+1+fin)/2);
            }
        }else{
            if(inicio>fin){
                return -inicio-1;
            }else
                return mitad;
        }
    }
    
    public String toString() {
        return toString(arr,total);
    }
    
    private String toString(T arr[], int total){
        StringBuilder str = new StringBuilder();
        if (total > 0) {
            str.append(arr[total-1]);
            return toString(arr,total-1); 
        }else{
            return str.toString();
        }
       
    }
    
    public int posMayor(T arr[], int n, int posMayor) {
        int pos;
        Comparable<T> aux;
        if (n < 0 || arr.length < n) {
            throw new NullPointerException("<n incorrecta: " + arr.length + ">");
        }

        if (n <= 0) {
            pos = posMayor;//Caso base
        } else {
            aux = (Comparable<T>) arr[n - 1];
            if (aux.compareTo(arr[posMayor]) > 0) {
                pos = posMayor(arr, n - 1, n - 1);
            } else {
                pos = posMayor(arr, n - 1, posMayor);
            }
        }
        return pos;
    }
    
    private void elimina (T dato){
        if(dato!= null && total>0){
            elimina(dato,0);
        }
    }
    
    private void elimina(T dato, int i){
        if(i<total){
            if(arr[i].equals(dato)){
                arr[i]=arr[total-1];
                total--;
                arr[total]=null;
                elimina(dato,i);
            }else{
                elimina(dato,i+1);
            }
        }
    }
    
    public void ordenaArreglo(){
        if(total>0){
            ordenaArreglo(0, 1, arr[0],0);
        }
    }
    
    private void ordenaArreglo(int i, int j, T menor, int pos){
        if(i<total-1){
            if(j<total){
                if(arr[j].compareTo(menor)<0){
                    menor= arr[j];
                    pos=j;
                }
                ordenaArreglo(i,j+1,menor,pos);
            }
            
        }else{
            arr[pos]=arr[i];
            arr[i]=menor;
            ordenaArreglo(i+1, i+2,arr[i+1],i+1);
        }
    }
    
    //Ejercicio para poner los coeficientes de un binomio:
    /*
    C0^n= 1 si n>=0
    Ck^n si k>n
    Ck^n= Ck-1^n-1 + Ck^n-1 en otro caso. 
    */
    public int coeficientesBinomiales(int n, int k){
        if(n>=0 && k==0){
            return 1;
        }else if(k>n){
            return 0;
        }else{
            return coeficientesBinomiales(n-1,k-1) + coeficientesBinomiales(n-1,k);
        }
    }
    
    /*
    A(0,n)=n+1
    A(m,0)=A(m-1,1)
    A(m,n)=A(m-1,A(m,n-1))  m,n>0
    */
    public int ackermman(int n, int m){
        //if(m>0 && n>0)
        if(m==0){
            return n+1;
        }else if(n==0){
            return ackermman(m-1,1);
        }else{
            return ackermman(m-1,ackermman(m,n-1));
        }
    }
    
}
