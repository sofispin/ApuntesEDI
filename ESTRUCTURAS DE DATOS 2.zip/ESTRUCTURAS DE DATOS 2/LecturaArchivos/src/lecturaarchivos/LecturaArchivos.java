/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lecturaarchivos;

import java.io.*;

/**
 *
 * @author SOFIA
 */
public class LecturaArchivos {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Alumno a1= new Alumno();
        Alumno a2= new Alumno();
        Alumno a3= new Alumno();
        
        //En este try SIII hay que cerrar archivo. 
        try{
            FileOutputStream file = new FileOutputStream("Alumnos");
            ObjectOutputStream escribe = new ObjectOutputStream(file);
            escribe.writeObject(a1);
            escribe.writeObject(a2);
            escribe.writeObject(a3);
            escribe.close();
        }catch(Exception e){
            System.out.println(e.getMessage());
        }
        impPromAlum("Alumnos");
        
    
        //En este catch NO hay que cerrar archivo!! Pero tengo que estar segura de que hay n 
        //elementos en mi documento y en mi arreglo. 
        //Esta mal porque falta la clase y el archivo. 
           /* try(FileInputStream file = new FileInputStream("Figuras");
                ObjectInputStream lee = new ObjectInputStream(file);){
                Integer n = (Integer)lee.readObject();
                FigGeom[] arre = new FigGeom[n];
                for (int i=0; i<n; i++){
                    arre[i]=(FigGeom)lee.readObject();
                }
            
            }catch(IOException e){ //o (ClassNotFoundException e)
                System.out.println(e.getMessage());
            }*/
    }

    //Este metodo te da la info de alumnos y su promedio, solo imprime el promedio de todos los alumnos que ya esta en el doc
    public static void impPromAlum(String nom){
        try{
            FileInputStream file = new FileInputStream(nom);
            ObjectInputStream lee = new ObjectInputStream(file);
            boolean bandera= true;
            Alumno al;
            while(bandera){
                try{
                    al = (Alumno)lee.readObject();
                    System.out.println("\n Nombre: " + al.getNombre() + "- promedio: " + al.calcularPromedio());
                }catch(IOException e){
                    bandera=false;
                }
            }
        }catch(Exception e){
            System.out.println(e.getMessage());
        }
    }
     
    
    
}

