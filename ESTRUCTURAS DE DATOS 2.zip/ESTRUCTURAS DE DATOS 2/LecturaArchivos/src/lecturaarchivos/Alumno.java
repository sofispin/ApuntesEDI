/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lecturaarchivos;

import java.io.Serializable;

/**
 *
 * @author SOFIA
 */
public class Alumno implements Serializable{
    
    // ATRIBUTOS
     private static int serie = 100; // Clave inicial de la clase
     private int claveUnica;
     private String nombre;
     private final int MAXCALIF = 45;
     private double [] calificaciones;
     private int totalCalif;
    
    // CONSTRUCTORES
     public Alumno() {
         claveUnica = serie;    serie++;
         nombre = "No hay nombre: " + claveUnica;
         calificaciones = new double[MAXCALIF];
         totalCalif = 0;
     }

     public Alumno(String nombreap) {
          claveUnica = serie;    serie++;
          nombre = nombreap;
          calificaciones = new double[MAXCALIF];
          totalCalif = 0;
          }
    
        // SET-TERS y GET-TERS
        public void setNombre(String nombreap) {
            nombre = nombreap;
        }
    
        public String getNombre() {
            return nombre;
        }

        public int getClaveUnica() {
            return claveUnica;
        }

    public double[] getCalificaciones() {
        return calificaciones;
    }
        
        
        
        // METODOS DE GESTION Y CALCULO
        // Metodo para dar de alta un alumno.
        public boolean altaCalificacion(double calif) {
           boolean sePudo=false;
            if(totalCalif<MAXCALIF){
                this.calificaciones[totalCalif]=calif;
                this.totalCalif++;
                sePudo=true;
            }
           return sePudo;
         }
    
        // Metodo para calcular el promedio de calificaciones
        public double calcularPromedio() {
            double suma=0;
            double promedio =0;
            if(this.totalCalif>0){
                for(int i=0; totalCalif>i; i++){
                    suma = suma + this.calificaciones[i];
                }
            promedio=suma/totalCalif;
            }
            return promedio;
         }
         
        // METODOS A SOBRE-ESCRIBIR, DE CLASES ASCENDENTES
        // Comparacion por igualdad con otro objeto Alumno
        // por claveUnica y nombreAlum
        @Override
        public boolean equals(Object otroObj) {
            if(otroObj == null) {
                return false;
            }
            if( this == otroObj) {
                return true;
            }
            if( this.getClass() != otroObj.getClass()) {
                return false;
            }

            Alumno otroAlum = (Alumno) otroObj;

            boolean bo1, bo2;
            bo1 = claveUnica == otroAlum.claveUnica;
            bo2 = nombre.compareTo(otroAlum.nombre) == 0;   // Identicos
            return bo1 && bo2;
         }
    
        // Obtencion del String del objeto
        @Override
        public String toString() {
            String cadena;
            cadena = "ALUMNO[" + claveUnica + "," + nombre + "\n";
            for(int i = 0; i < totalCalif; i++) {
                cadena = cadena + calificaciones[i] + ",";
            }
            cadena = cadena + "]\n";
            return cadena;
        }
    
    
}
