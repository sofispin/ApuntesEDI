/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package problema7;

/**
 *
 * @author SOFIA
 */
public class Aplicacion {
    
    private String aeropuerto;
    private Pajaro[] pajaros;
    private Avion[] aviones;
    private final int MAX=10;
    private int totalPajaros=0;
    private int totalAviones=0;

    public Aplicacion() {
        aeropuerto="Aero";
        pajaros = new Pajaro[MAX];
        aviones = new Avion[MAX];
    }

    public Aplicacion(String aeropuerto) {
        this();
        this.aeropuerto = aeropuerto;
    }
     
    public boolean altaPajaro(Pajaro paj){
        boolean sePudo=false;
        
        while(this.totalPajaros<MAX){
            this.pajaros[totalPajaros]=paj;
            totalPajaros++;
            sePudo=true;
        }
        return sePudo;
    }
    
    public boolean altaAvion(Avion av){
        boolean sePudo=false;
        
        while(this.totalAviones<MAX){
            this.aviones[totalAviones]=av;
            totalAviones++;
            sePudo=true;
        }
        return sePudo;
    }
    
    
    public boolean busquedaPajaro(int paj){
        boolean seAlmaceno=false;
        for (int i=0; i<totalPajaros;i++){
            if(this.pajaros[i].getSerie()==paj){
                seAlmaceno=true;
                System.out.println(this.pajaros[i].toString());
            }
                
        }
        return seAlmaceno;
    }
    
    public int numeroPasajeros(int avi){
        int MAX=0;
        for (int i=0; i<totalAviones;i++){
            if(this.aviones[i].getSerie()==avi && this.aviones[i].getTipoAvion() == "pasajeros"){
                MAX = this.aviones.length;
            }   
        }
        return MAX;
    }
    
    public boolean actualizarHabitat(int paj, String habit){
        boolean sePudo = false;
        for (int i=0; i<totalPajaros;i++){
            if(this.pajaros[i].getSerie()==paj){
                this.pajaros[i].setHabitat(habit);
                System.out.println(this.pajaros[i].toString());
                sePudo=true;
            }
        }
        return sePudo;
    }
    
}
