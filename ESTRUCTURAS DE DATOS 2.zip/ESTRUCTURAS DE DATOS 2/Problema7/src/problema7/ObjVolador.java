/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package problema7;

/**
 *
 * @author SOFIA
 */
public interface ObjVolador {
    
    public void despega();
    public void aterriza();
    public void seDesplaza();
    
}
