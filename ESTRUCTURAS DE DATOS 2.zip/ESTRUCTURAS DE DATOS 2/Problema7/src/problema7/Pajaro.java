/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package problema7;

/**
 *
 * @author SOFIA
 */
public class Pajaro implements ObjVolador{
    
    private String especie;
    private static int serie=100;
    private String habitat;

    public Pajaro() {
        serie++;
    }

    public Pajaro(String especie, String habitat) {
        this();
        this.especie = especie;
        this.habitat = habitat;
    }

    public String getEspecie() {
        return especie;
    }

    public String getHabitat() {
        return habitat;
    }

    public void setHabitat(String habitat) {
        this.habitat = habitat;
    }

    public int getSerie() {
        return serie;
    }
    
    public void despega(){
        System.out.println("No despega");
    }
    
    public void aterriza(){
        System.out.println("Si aterriza");
    }
    
    public void seDesplaza(){
        System.out.println("Si se desplaza");
    }
}
