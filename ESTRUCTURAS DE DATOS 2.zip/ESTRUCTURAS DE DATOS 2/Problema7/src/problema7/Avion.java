/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package problema7;

/**
 *
 * @author SOFIA
 */
public class Avion implements ObjVolador {
    
    private String tipoAvion;
    private static int serie=100;
    private String compania;

    public Avion() {
        serie ++;
        tipoAvion="No hay info";
        compania="No hay info";
    }

    public Avion(String compania, String tipoAvion) {
        this();
        this.compania = compania;
        this.tipoAvion = tipoAvion;
    }

    public String getTipoAvion() {
        return tipoAvion;
    }

    public void setTipoAvion(String tipoAvion) {
        this.tipoAvion = tipoAvion;
    }

    public String getCompania() {
        return compania;
    }

    public void setCompania(String compania) {
        this.compania = compania;
    }
    
    public int getSerie(){
        return serie;
    }
    
      public void despega(){
        System.out.println("No despega");
    }
    
    public void aterriza(){
        System.out.println("Si aterriza");
    }
    
    public void seDesplaza(){
        System.out.println("Si se desplaza");
    }
    
}
