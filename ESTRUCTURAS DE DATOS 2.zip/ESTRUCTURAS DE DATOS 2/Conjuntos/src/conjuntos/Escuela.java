/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package conjuntos;

import java.util.Iterator;

/**
 *
 * @author SOFIA
 */
public class Escuela {
    
    private String nombre;
    private String direccion;
    private ConjuntoA<Alumno> ingenieria;
    private ConjuntoA<Alumno> licenciatura;

    public Escuela(String nombre, String direccion) {
        this.nombre = nombre;
        this.direccion = direccion;
        this.ingenieria = new ConjuntoA();
        this.licenciatura = new ConjuntoA();
    }
    
    public boolean agregaAlumno(String nombre, String carrera){
        Alumno al= new Alumno(nombre, carrera);
        boolean sePudo=false;
        if(al.getCarrera().equals("ingenieria")){
            ingenieria.agrega(al);
            sePudo=true;
        }else{
            licenciatura.agrega(al);
            sePudo=true;
        }
        return sePudo;
    }
    
    public boolean eliminaAlumno(Alumno al){
        boolean sePudo=true;
        if(ingenieria.contiene(al)){
            ingenieria.quita(al);
        }else if(licenciatura.contiene(al)){
            licenciatura.quita(al);
        }else{
            sePudo=false;
        }
        return sePudo;
    }
    
    public String toString(){
        ConjuntoADT <Alumno> nuevo = new ConjuntoA();
        Iterator <Alumno> it = ingenieria.iterator();
        Iterator <Alumno> it2 = licenciatura.iterator();
        StringBuilder str = new StringBuilder();
        nuevo= licenciatura.interseccion(ingenieria);
        if(it.hasNext()){
            str.append(ingenieria.toString());
        }else if(it2.hasNext()){
            str.append(licenciatura.toString());
        }
        return str.toString();
    }
    
    public String licenciaturaeIng(){
        ConjuntoADT <Alumno> nuevo = new ConjuntoA();
        nuevo = ingenieria.interseccion(licenciatura);
        return nuevo.toString();
    }
    
    public String licenciaturaoingenieria(){
        ConjuntoADT <Alumno> nuevo = new ConjuntoA();
        nuevo = (ingenieria.diferencia(licenciatura)).union(licenciatura.diferencia(ingenieria));
        return nuevo.toString();
    }
    
    public double promedios(){
        Iterator it= ingenieria.iterator();
        Iterator it2 = licenciatura.iterator();
        return 4;
    }
   
}
