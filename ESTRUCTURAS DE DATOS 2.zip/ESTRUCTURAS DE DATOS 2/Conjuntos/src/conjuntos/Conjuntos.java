/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package conjuntos;

import java.util.Iterator;

/**
 *
 * @author SOFIA
 */
public class Conjuntos {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        ConjuntoA<Integer> c1 = new ConjuntoA();
        ConjuntoA<Integer> c2 = new ConjuntoA();

        c1.agrega(1);
        c1.agrega(2);
        c2.agrega(2);

        System.out.println(c1.equalsIt(c2));

    }

    /*//For each
    for(String s: ingles){
            System.out.println(" " + s);
    }*/
    //EJERCICIO 20
    public static String inglesYFrances(ConjuntoADT<String> ingles, ConjuntoADT<String> frances) {
        if (ingles == null || frances == null) {
            throw new NullPointerException();
        }
        return ingles.interseccion(frances).toString();

    }

    public static int dominanIngles(ConjuntoADT<String> ingles, ConjuntoADT<String> frances, ConjuntoADT<String> otro) {
        if (ingles == null || frances == null || otro == null) {
            throw new NullPointerException();
        }
        return (ingles.diferencia(frances)).diferencia(otro).getCardin();
    }

    public static String dominanTresIdiomas(ConjuntoADT<String> ingles, ConjuntoADT<String> frances, ConjuntoADT<String> otro) {
        if (ingles == null) {
            throw new NullPointerException();
        }

        return (ingles.interseccion(frances)).interseccion(otro).toString();
    }

    public static boolean analizaDeportivos(ConjuntoADT<Auto> cA, int n) {
        if (cA == null) {
            throw new NullPointerException();
        }
        if (cA.estaVacio()) {
            throw new EmptyCollectionException();
        }
        if (n < 0) {
            int cont = 0;
            Iterator<Auto> it = cA.iterator();
            while (it.hasNext() && n > cont) {
                if (it.next().getVelocidades() >= 5) {
                    cont++;
                }
            }
            if (cont >= n) {
                return true;
            } else {
                return false;
            }
        } else {
            throw new NullPointerException();
        }
    }

    public static <T> boolean esSuperConjuntoDe(ConjuntoADT<T> uno, ConjuntoADT<T> dos) {
        if (uno == null || dos == null) {
            throw new NullPointerException();
        }
        if (uno.estaVacio()) {
            throw new EmptyCollectionException();
        }
        if (dos.estaVacio()) {
            return true;
        } else if (dos.getCardin() > uno.getCardin()) {
            return false;
        } else {
            return esSuperConjuntoDe(uno, dos.iterator());
        }
    }
    
    private static <T> boolean esSuperConjuntoDe(ConjuntoADT <T> uno, Iterator<T> it){
        if(!it.hasNext()){
            return true;
        }else{
            if(uno.contiene(it.next())){
                return esSuperConjuntoDe(uno, it);
            }else{
                return false;
            }
        }
    }
}
