/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package conjuntos;

import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 *
 * @author SOFIA
 */
public class IteradorArreglo <T> implements Iterator <T> {
    
    private T[] coleccion;
    private int actual;
    private int total;
    
    //Recibe mi coleccion y mi numero de datos en el arreglo
    public IteradorArreglo(T[] colec, int n){
        actual=0;
        total=n;
        coleccion=colec;
    }
    
    public boolean hasNext(){
        return actual<total;
    }
    
    public T next(){
        if(!hasNext()){
            throw new NoSuchElementException();
        }
        T resul;
        resul=coleccion[actual];
        actual++;
        return resul;
    }
    
    public void remove(){
        throw new UnsupportedOperationException("No esta implementado");
    }
}
