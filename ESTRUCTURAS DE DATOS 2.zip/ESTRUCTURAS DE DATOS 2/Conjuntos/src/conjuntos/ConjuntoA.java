/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package conjuntos;

import java.util.Iterator;

/**
 *
 * @author SOFIA
 */
public class ConjuntoA <T> implements ConjuntoADT <T>{
    
    private T[] conjunto;
    private int cardinalidad;
    private final int MAX=20;
    
    public ConjuntoA(){
        conjunto = (T[]) new Object[MAX];
        cardinalidad=0;
    }
    
    public ConjuntoA(int max){
        conjunto = (T[]) new Object[max];
        cardinalidad=0;
    }
    
    public Iterator <T> iterator(){
        return new IteradorArreglo(conjunto,cardinalidad);
    }
    
    public boolean contiene(T elem){
        boolean resp=false;
        Iterator <T> it = iterator();
        while(it.hasNext() && !it.next().equals(elem)){
            resp=it.next().equals(elem);
        }
        return resp;
    }
    
    //Contiene Recursivo
    private boolean contieneRec(Iterator <T> it, T elem){
        if(!it.hasNext()){
            return false;
        }else if(it.next().equals(elem)){
            return true;
        }else{
            return contieneRec(it,elem);
        }
    }
    
    public boolean contieneRec(T elem){
        Iterator <T> it = iterator();
        return contieneRec(it,elem);
    }
    
    //AGREGA
    public boolean agrega(T elem){
        boolean resp = false;
        if(elem!= null && !contiene(elem)){
            if(cardinalidad == conjunto.length){
                expande();
            }
            conjunto[cardinalidad]=elem;
            cardinalidad++;
            resp=true;
        }
        return resp; 
    }
    
    //TOSTRING
    public String toString(){
        return toString(0, new StringBuilder());
    }
    
    private String toString(int indice, StringBuilder str){
        if(indice==cardinalidad){
            return str.toString();
        }else{
            str.append(conjunto[indice]).append("\n");
            return toString(indice+1,str);
        }
    }
    
    //QUITAR
    public T quita (T elem){
        T resp=null;
        if(elem!=null){
            int pos;
            pos=busca(elem,0);
            if(pos>=0){
                resp=conjunto[pos];
                conjunto[pos]=conjunto[cardinalidad-1];
                conjunto[cardinalidad-1]=null;
                cardinalidad--;
            }
        }
        return resp;
    }
    
    //ISEMPTY
    public boolean estaVacio(){
        return cardinalidad==0;
    }
    
    public ConjuntoADT<T> union(ConjuntoADT<T> otro){
        if(otro == null){
            throw new RuntimeException();
        }
        ConjuntoA<T> nuevo = new ConjuntoA(cardinalidad);
        for(int i=0; i<cardinalidad;i++){
            nuevo.conjunto[i] = this.conjunto[i];
        }
        Iterator <T> it = otro.iterator();
        while(it.hasNext()){
            nuevo.agrega(it.next());
        }
        return nuevo;
    }
    
    public ConjuntoADT<T> interseccion(ConjuntoADT<T> otro){
        if(otro == null){
            throw new RuntimeException();
        }
        ConjuntoA<T> nuevo = new ConjuntoA(cardinalidad);
        Iterator <T> it = otro.iterator();
        while(it.hasNext()){
            T aux = it.next();
            if(this.contiene(aux)){
                nuevo.agrega(aux);
            }
        }
        return nuevo;
    }
    
    /*public ConjuntoADT<T> interseccionRec(ConjuntoADT<T> otro){
        if(otro == null){
            throw new RuntimeException();
        }
        ConjuntoA<T> nuevo = new ConjuntoA(cardinalidad);
        Iterator <T> it = otro.iterator();
        while(it.hasNext()){
            T aux = it.next();
            if(this.contiene(aux)){
                nuevo.agrega(aux);
            }
        }
        return nuevo;
    }
    
    private ConjuntoADT <T> interseccionRec(ConjuntoADT<T> otro, ConjuntoA <T> nuevo, T aux){
        if(!otro.contiene(aux)){
            return nuevo;
        }else{
            return interseccionRec(otro, nuevo,aux);
        }
    }*/

    public int getCardin() {
        return cardinalidad;
    }
    
    //Interseccion EFICIENTE
    public ConjuntoADT<T> interseccionEficiente(ConjuntoADT<T> otro){
        if(otro == null){
            throw new RuntimeException();
        }
        ConjuntoA<T> nuevo = new ConjuntoA(cardinalidad);
        int j=0;
        for(int i=0; i<this.cardinalidad;i++){
            if(otro.contiene(conjunto[i])){
                nuevo.conjunto[j]=conjunto[i];
                j++;
            }
        }
        nuevo.cardinalidad=j;
        return nuevo;
    }
    
    //Quitarle al this todo lo del otro.
    public ConjuntoADT<T> diferencia(ConjuntoADT<T> otro){
        if(otro == null){
            throw new RuntimeException();
        }
        ConjuntoA<T> nuevo = new ConjuntoA(cardinalidad);
        Iterator <T> it = iterator();
        while(it.hasNext()){
            T aux = it.next();
            if(!this.contiene(aux)){
                nuevo.agrega(aux);
            }
        }
        return nuevo;
    }
    
    public ConjuntoADT<T> diferenciaEficiente(ConjuntoADT<T> otro){
        if(otro == null){
            throw new RuntimeException();
        }
        int n=0;
        ConjuntoA<T> nuevo = new ConjuntoA(cardinalidad);
        for(int i=0; i<cardinalidad;i++){
            if(!otro.contiene(conjunto[i])){
                nuevo.conjunto[n]=this.conjunto[i];
                n++;
            }
        }
        nuevo.cardinalidad=n;
        return nuevo;
    }
    
    public boolean equals(ConjuntoADT<T> otro){
        if(otro == null){
            throw new NullPointerException();
        }
        return this.interseccion(otro).getCardin() == this.cardinalidad && otro.interseccion(this).getCardin() == otro.getCardin();
    }
    
    public boolean equalsIt(ConjuntoADT<T> otro){
        if(otro == null){
            throw new NullPointerException();
        }
        boolean resp=true;
        if(this.cardinalidad == otro.getCardin()){
            Iterator <T> it = iterator();
            while(resp && it.hasNext() ){
                if(!otro.contiene(it.next())){
                    resp=false;
                }
            }
        }else{
            resp=false;
        }
        return resp;
    }
    
    public boolean equalsItRec(ConjuntoADT<T> otro){
        if(otro == null){
            throw new NullPointerException();
        }
        boolean resp = true;
        if(this.cardinalidad == otro.getCardin()){
            Iterator <T> it = iterator();
            return equalsItRec(otro, resp, it);
        }else{
            return false;
        }
        
    }
    
    private boolean equalsItRec(ConjuntoADT <T> otro, boolean resp, Iterator<T> it){
        if(resp && it.hasNext()){
            return equalsItRec(otro,otro.contiene(it.next()), it);
        }else{
            return resp;
        }
    }
    
    public boolean esSubconjunto(ConjuntoADT<T> otro){
        if(otro == null){
            throw new NullPointerException();
        }else if(otro.getCardin() > cardinalidad){
            return false;
        }else{
            return esSubconjunto(otro.iterator());
        }
    }
    
    private boolean esSubconjunto(Iterator<T> it){
        if(it.hasNext()){
            if(this.contiene(it.next())){
                return esSubconjunto(it);
            }else{
                return false;
            }
        }else{
            return true;
        }
    }
    
    public boolean esAjeno(ConjuntoADT<T> uno, ConjuntoADT<T> dos){
        if(uno == null || dos == null){
            throw new NullPointerException();
        }else if(uno.estaVacio() || dos.estaVacio()){
            return true;
        }else{
            return esAjeno(uno.iterator(), dos);
        }
    }
    
    private boolean esAjeno(Iterator<T> uno, ConjuntoADT<T> dos){
        if(uno.hasNext()){
            if(!dos.contiene(uno.next())){
                return esAjeno(uno, dos);
            }else{
                return false;
            }
        }else{
            return true;
        }
    }
    
    //METODOS PRIVADOS
    //EXPAND CAPACITY
    private void expande(){
        T[] nuevo = (T[]) new Object[cardinalidad*2];
        for(int i=0; i<=cardinalidad; i++){
            nuevo[i]=conjunto[i];
        }
        conjunto = nuevo;
    }
    
    //BUSCA ELEMENTO
    private int busca(T elem, int i){
        if(cardinalidad == i){
            return -1;
        }else if(conjunto[i].equals(elem)){
            return i;
        }else{
            return busca(elem, i+1);
        }
    }
    
    
}
