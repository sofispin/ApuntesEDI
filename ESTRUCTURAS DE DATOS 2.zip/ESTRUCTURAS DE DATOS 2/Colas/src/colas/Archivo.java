/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package colas;

import java.util.ArrayList;

/**
 *
 * @author SOFIA
 */
public class Archivo {
    private double tamaño;
    private String nombre;
    private String dueno;
    private String fecha;
    private ArrayList<Archivo> archivos;

    public Archivo() {
        this.dueno= "Yo";
        this.tamaño = 2;
        this.fecha= "Hoy";
        this.nombre = "Doc";
        archivos = new ArrayList();
    }

    public Archivo(double tamaño, String nombre, String dueno, String fecha) {
        this.tamaño = tamaño;
        this.nombre = nombre;
        this.dueno = dueno;
        this.fecha = fecha;
        archivos = new ArrayList();
    }

    public double getTamaño() {
        return tamaño;
    }

    public String getNombre() {
        return nombre;
    }

    public String getDueno() {
        return dueno;
    }

    public String getFecha() {
        return fecha;
    }
    
    public boolean agregaArchivo(Archivo arch){
        boolean sePudo = false;
        if(arch != null){
            archivos.add(arch);
            sePudo = true;
        }
        return sePudo;
    }
    
    
    
}
