/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package colas;

/**
 *
 * @author SOFIA
 */
public class Documento extends Archivo{
    
    private String tipoProcesador;

    public Documento(String tipoProcesador) {
        this.tipoProcesador = tipoProcesador;
    }

    public Documento(double tamaño, String nombre, String dueno, String fecha, String tipoProcesador ) {
        super(tamaño, nombre, dueno, fecha);
        this.tipoProcesador = tipoProcesador;
    }

    public String getTipoProcesador() {
        return tipoProcesador;
    }

    
    
    
}
