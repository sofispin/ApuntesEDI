/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package colas;

import java.util.ArrayList;

/**
 *
 * @author SOFIA
 */
public class Impresora {
    private String marca;
    private ColaA <Archivo> pendientes; 

    public Impresora() {
        pendientes = new ColaA();
    }

    public Impresora(String marca) {
        this();
        this.marca = marca;
    }

    public String getMarca() {
        return marca;
    }
    
    public void archivos(ArrayList<Archivo> arch){
        if(arch.isEmpty()){
            throw new EmptyCollectionException();
        }
        if(arch == null){
            throw new NullPointerException();
        }
        for(int i=0; i<arch.size(); i++){
            anadirArchivo(arch.remove(i));
        }
    }
    
    public boolean anadirArchivo(Archivo arch){
        boolean sePudo=false;
        if(arch != null && this.pendientes!= null){
            pendientes.insertar(arch);
            sePudo = true;
        }
        return sePudo;
    }
    
    public String imprimir(){
        if(this.pendientes == null){
            throw new NullPointerException();
        }
        if(this.pendientes.isEmpty()){
            throw new EmptyCollectionException();
        }
        StringBuilder str = new StringBuilder();
        ColaADT aux = new ColaA();
        while(!this.pendientes.isEmpty()){
            str.append(this.pendientes.consultaPrimero() + " ");
            aux.insertar(this.pendientes.eliminar());
        }
        while(!aux.isEmpty()){
            this.pendientes.insertar((Archivo) aux.eliminar());
        }
        return str.toString();
    }
    public void eliminarFotos(){
        if(this.pendientes == null){
            throw new NullPointerException();
        }
        if(this.pendientes.isEmpty()){
            throw new EmptyCollectionException();
        }
        
        ColaADT aux = new ColaA();
        while(!pendientes.isEmpty()){
            if(pendientes.consultaPrimero() instanceof Foto){
                pendientes.eliminar();
            }else{
                aux.insertar(pendientes.eliminar());
            }
        }
        while(!aux.isEmpty()){
            pendientes.insertar((Archivo) aux.eliminar());
        }
    }
    
    public void eliminarArchivos(){
        if(this.pendientes == null){
            throw new NullPointerException();
        }
        if(this.pendientes.isEmpty()){
            throw new EmptyCollectionException();
        }
        
        ColaADT aux = new ColaA();
        while(!pendientes.isEmpty()){
            if(pendientes.consultaPrimero().getClass().getSimpleName().equals("Documento") && pendientes.consultaPrimero().getTamaño() > 500){
                pendientes.eliminar();
            }else{
                aux.insertar(pendientes.eliminar());
            }
        }
        while(!aux.isEmpty()){
            pendientes.insertar((Archivo) aux.eliminar());
        }
    }
    
}
