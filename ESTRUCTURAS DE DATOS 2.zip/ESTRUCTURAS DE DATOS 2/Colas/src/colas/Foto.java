/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package colas;

/**
 *
 * @author SOFIA
 */
public class Foto extends Archivo{
    
    private double resolucion; 

    public Foto(double resolucion) {
        this.resolucion = resolucion;
    }

    public Foto(double tamaño, String nombre, String dueno, String fecha, double resolucion) {
        super(tamaño, nombre, dueno, fecha);
        this.resolucion = resolucion;
    }

    public double getResolucion() {
        return resolucion;
    }
    
    
}
