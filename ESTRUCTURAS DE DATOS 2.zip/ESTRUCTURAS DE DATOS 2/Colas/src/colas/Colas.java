/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package colas;

import java.util.ArrayList;
import pilas.*;

/**
 *
 * @author SOFIA
 */
public class Colas {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //Ejercicios 27 y 28

        ColaA cola1 = new ColaA();
        cola1.insertar("h");
        cola1.insertar("o");
        cola1.insertar("l");
        cola1.insertar("a");

        System.out.println("Inversión de Cola: " + "\n");
        System.out.println("Cola Original:" + cola1.imprimir());
        invertir(cola1);
        System.out.println("Cola Final:" + cola1.imprimir() + "\n");

        ColaA cola2 = new ColaA();
        cola2.insertar("a");
        cola2.insertar("b");
        cola2.insertar("b");
        cola2.insertar("c");

        System.out.println("Quitar repetidos de Cola: " + "\n");
        System.out.println("Cola Original:" + cola2.imprimir());
        quitarRepetidos(cola2);
        System.out.println("Cola Final:" + cola2.imprimir() + "\n");
        
        System.out.println("Quitar un dato: " + "\n");
        System.out.println("Cola Original:" + cola1.imprimir());
        quitarElem(cola1, "o");
        System.out.println("Cola Final: " + cola1.imprimir() + "\n");
    }

      public static <T> ColaA invertir(ColaADT<T> cola) {
        if (cola == null) {
            throw new NullPointerException("Cola Nula");
        }
        if (cola.isEmpty()) {
            throw new EmptyCollectionException("Cola Vacia");
        }
        ArrayList<T> aux = new ArrayList();
        while (!cola.isEmpty()) {
            aux.add(cola.eliminar());
        }
        int i = aux.size() - 1;
        while (!aux.isEmpty()) {
            cola.insertar(aux.remove(i));
            i--;
        }
        return (ColaA) cola;
    }

    //Mismo metodo pero void
    public static <T> void invertir2(ColaADT<T> cola) {
        if (cola == null) {
            throw new NullPointerException("Cola Nula");
        }
        if (cola.isEmpty()) {
            throw new EmptyCollectionException("Cola Vacia");
        }
        ArrayList<T> aux = new ArrayList();
        while (!cola.isEmpty()) {
            aux.add(cola.eliminar());
        }
        int i = aux.size() - 1;
        while (!aux.isEmpty()) {
            cola.insertar(aux.remove(i));
            i--;
        }
    }

    //Mismo metodo pero usando una pila auxiliar
    public static <T> void invertir3(ColaADT<T> cola) {
        if (cola == null) {
            throw new NullPointerException("Cola Nula");
        }
        if (cola.isEmpty()) {
            throw new EmptyCollectionException("Cola Vacia");
        }
        PilaADT<T> aux = new PilaA();
        while (!cola.isEmpty()) {
            aux.push(cola.eliminar());
        }
        while (!aux.isEmpty()) {
            cola.insertar(aux.pop());
        }
    }

    //MAS EFICIENTE!!!!
    public static <T> ColaA quitarRepetidos(ColaADT<T> cola) {
        /*if (cola == null) {
            throw new NullPointerException("Cola Nula");
        }
        if (cola.isEmpty()) {
            throw new EmptyCollectionException("Cola Vacia");
        }*/
          if (cola != null && !cola.isEmpty()) {
            ColaADT <T> aux = new ColaA();
            T elem = cola.eliminar();
            while (!cola.isEmpty()) {
                if (elem.equals(cola.consultaPrimero())) {
                    cola.eliminar();
                } else {
                    aux.insertar(elem);
                    elem = cola.eliminar();
                }
            }
            aux.insertar(elem);
            while (!aux.isEmpty()) {
                cola.insertar(aux.eliminar());
            }
        }
        return (ColaA) cola;
    }

    //MISMO METODO PERO MENOS EFICIENTE
    public static <T> ColaA quitarRepetidos2(ColaADT<T> cola) {
        if (cola == null) {
            throw new NullPointerException("Cola Nula");
        }
        if (cola.isEmpty()) {
            throw new EmptyCollectionException("Cola Vacia");
        }
        ArrayList aux = new ArrayList();
        T elem;
        int i = 1;
        while (!cola.isEmpty()) {
            aux.add(cola.eliminar());
        }
        while (i < aux.size()) {
            if (!aux.get(i).equals(aux.get(i--))) {
                aux.remove(i);
                i--;
            }
            i++;
        }

        for (int j = 0; j < aux.size(); j++) {
            cola.insertar((T) aux.get(j));
        }

        return (ColaA) cola;
    }

    //EJERCICIO 29
    public static <T> ColaA quitarElem(ColaADT<T> cola, T dato) {
        if (cola != null && !cola.isEmpty()) {
            ColaADT<T> aux = new ColaA();
            while (!cola.isEmpty()) {
                if (!cola.consultaPrimero().equals(dato)) {
                    aux.insertar(cola.eliminar());
                } else {
                    cola.eliminar();
                }
            }
            while (!aux.isEmpty()) {
                cola.insertar(aux.eliminar());
            }
        }
        return (ColaA) cola;
    }
     
    //EJERCICIO 30
    public static <T> boolean estaNVeces(ColaADT <T> cola, T dato, int n){
        if(cola == null){
            throw new NullPointerException();
        }
        if(cola.isEmpty()){
            throw new EmptyCollectionException();
        }
        ColaADT <T> aux = new ColaA();
        while(!cola.isEmpty()){
            aux.insertar(cola.eliminar());
        }
        //int cont = 0;
        while(!aux.isEmpty() && n==0){
            if(aux.consultaPrimero().equals(dato)){
                n--;
            }else{
                cola.insertar(aux.eliminar());
            }
        }
        if(n!=0){
            while(!aux.isEmpty()){
                cola.insertar(aux.eliminar());
            }
        }
        return n==0;
    }
}
