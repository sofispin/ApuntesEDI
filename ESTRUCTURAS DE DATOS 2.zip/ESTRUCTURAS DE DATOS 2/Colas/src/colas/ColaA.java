/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package colas;

/**
 *
 * @author SOFIA FIFO
 */
public class ColaA<T> implements ColaADT<T> {

    private T[] cola;
    private int inicio, fin;
    private final int MAX = 20;

    public ColaA() {
        cola = (T[]) new Object[MAX];
        inicio = -1;
        fin = -1;
    }

    public ColaA(int max) {
        cola = (T[]) new Object[max];
        inicio = -1;
        fin = -1;
    }

    public void insertar(T dato) { //Solo expande si mi pila esta completamente llena
        if ((fin + 1) % cola.length == inicio) {//inicio==0 && fin== cola.length-1 || fin == inicio-1
            expandCapacity();
        }
        fin = (fin + 1) % cola.length;
        cola[fin] = dato;
        if (inicio == -1) {
            inicio = 0;
        }
    }

    public T eliminar() {
        if (isEmpty()) {
            throw new EmptyCollectionException("Cola Vacia");
        }
        T resul;
        resul = cola[inicio];
        cola[inicio] = null;
        if (inicio == fin) {
            inicio = -1;
            fin = -1;
        } else {
            inicio = (inicio + 1) % cola.length;
        }
        return resul;
    }

    public boolean isEmpty() {
        return inicio == -1;
    }

    public T consultaPrimero() {
        if (isEmpty()) {
            throw new EmptyCollectionException("Cola Vacia");
        }
        return cola[inicio];
    }

    private void expandCapacity() {
        T[] nuevo = (T[]) new Object[cola.length * 2];
        int i, j = 0;

        for (i = inicio; i < cola.length; i++) {
            nuevo[j] = cola[i];
            j++;
        }
        for (i = 0; i < inicio; i++) {
            nuevo[j] = cola[i];
            j++;
        }
        cola = nuevo;
        inicio = 0;
        fin = j - 1;
    }

    //Impresion de Cola
    public String imprimir() {
        StringBuilder str = new StringBuilder();
        ColaA<T> aux = new ColaA();
        while (!isEmpty()) {
            aux.insertar(this.consultaPrimero());
            str.append(this.eliminar());
            str.append(" ");
        }
        while (!aux.isEmpty()) {
            this.insertar(aux.eliminar());
        }
        return str.toString();
    }

    public boolean noHayVecinosIguales() { 
        if (isEmpty()) {
            throw new EmptyCollectionException();
        }
        boolean resp = true;
        if (inicio == fin) {
            return resp;
        } else {
            ColaADT<T> aux = new ColaA();
            T elem = this.eliminar();
            while (!resp && !this.isEmpty()) {
                if (elem.equals(this.consultaPrimero())) {
                    resp = false;
                }else{
                    aux.insertar(elem);
                    elem = this.eliminar();
                }
            }
            aux.insertar(elem);
            while(!isEmpty()){
                aux.insertar(this.eliminar());
            }
            while(!aux.isEmpty()){
                this.insertar(aux.eliminar());
            }
        }
        return resp;
    }
    
    

}
