/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package listasdobles;

import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 *
 * @author SOFIA
 */
public class IteradorDoble <T> implements Iterator <T>{
    private NodoDoble <T> actual; //Guarda la dreccion de un nodo
    
    public IteradorDoble(NodoDoble <T> nodo){
        actual = nodo;
    }
    
    public boolean hasNext(){
        return actual != null;
    }
    
    public T next(){
        if(!hasNext()){
            throw new NoSuchElementException();
        }
        T res = actual.getDato();
        actual = actual.getSiguiente();
        return res;
    }
    
    public void remove(){
        throw new UnsupportedOperationException("No esta implementado");
    }
}
