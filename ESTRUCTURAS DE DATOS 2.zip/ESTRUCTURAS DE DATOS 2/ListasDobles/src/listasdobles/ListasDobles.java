/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package listasdobles;

/**
 *
 * @author SOFIA
 */
public class ListasDobles {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        ListaDoble<String> meses = new ListaDoble();
        ListaDoble<Integer> num = new ListaDoble();
        
        meses.agregaPrimero("Junio");
        meses.agregaPrimero("Noviembre");
        meses.agregaUltimo("Febrero");
        System.out.println("Lista meses: " + meses);
        
        System.out.println("Primero: " + meses.eliminaPrimero());
        
        System.out.println("Quita ultimo a num: " + num.eliminaUltimo());
        
        System.out.println("Contiene Octubre: " + meses.contiene("Octubre"));
        System.out.println("Contiene Febrero: " + meses.contiene("Febrero"));
        System.out.println("Agrega 18 antes de 16: " + num.agregaAntesQue(16, 18));
        num.agregaUltimo(20);
        num.agregaUltimo(17);
        System.out.println("Agrega 40 antes de 20: " + num.agregaAntesQue(20, 40));
        System.out.println("Lista Numeros: " + num);
        System.out.println("Agrega 10 antes de 15: " + num.agregaAntesQue(15, 10));
        System.out.println("Elimina 20: " + num.elimina(20));
        System.out.println("Lista Numeros: " + num);
        System.out.println("Elimina 19: " + num.elimina(19));
        System.out.println("Lista: " + num);
    }
    
    
    
}
