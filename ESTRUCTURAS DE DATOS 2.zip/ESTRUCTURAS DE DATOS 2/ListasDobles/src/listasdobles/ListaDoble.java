/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package listasdobles;

import java.util.Iterator;

/**
 *
 * @author SOFIA
 */
public class ListaDoble <T> implements Iterable<T>{
    private NodoDoble<T> primero;
    private NodoDoble<T> ultimo;
    
    public ListaDoble(){
        primero = null;
        ultimo = null;
    }
    
    public Iterator<T> iterator(){
        return new IteradorDoble(primero);
    }
    
    public boolean estaVacia(){
        return primero==null;
    }
    
    public void agregaPrimero(T dato){
        NodoDoble <T> nuevo = new NodoDoble(dato);
        if(!estaVacia()){
            nuevo.setSiguiente(primero);
            primero.setAnterior(nuevo);
        }else{
            ultimo = nuevo;
        }
        primero = nuevo;
    }
    
    public void agregaUltimo(T dato){
        NodoDoble <T> nuevo = new NodoDoble(dato);
        if(!estaVacia()){
            nuevo.setAnterior(ultimo);
            ultimo.setSiguiente(nuevo);
        }else{
            primero = nuevo;
        }
        ultimo = nuevo;
    }
    
    public String toString(){
        return toString(new StringBuilder(), ultimo);
    }
    
    private String toString(StringBuilder str, NodoDoble<T> apunt){
        if(apunt != null){
            str.append(apunt.getDato());
            str.append(" ");
            return toString(str, apunt.getAnterior());
        }else{
            return str.toString();
        }
    }
    
    public T elimina(T dato){
        T resp=null;
        if(!estaVacia())
            if(ultimo.getDato().equals(dato)){
                resp= eliminaUltimo();
            }else if(primero.getDato().equals(dato)){
                resp = eliminaPrimero();
            }else{
                resp = elimina(dato, primero.getSiguiente());
            }
        return resp;
    }
    
    private T elimina(T dato, NodoDoble<T> apunt){
        if(apunt==null){
            return null; //Caso de fracaso
        }else{
            if(apunt.getDato().equals(dato)){
                apunt.getAnterior().setSiguiente(apunt.getSiguiente());
                apunt.getSiguiente().setAnterior(apunt.getAnterior());
                apunt.setAnterior(null);
                apunt.setSiguiente(null);
                return apunt.getDato();
            }else{
                return elimina(dato, apunt.getSiguiente());
            }
        }
    }
    
    public T eliminaPrimero(){
        T resp = null;
        if(!estaVacia()){
           resp=primero.getDato();
           if(primero == ultimo){
               primero=null;
               ultimo=null;
           }else{
               primero = primero.getSiguiente();
               primero.getAnterior().setSiguiente(null);
               primero.setAnterior(null);
           }
        }
        return resp;
    }
    
    public T eliminaUltimo(){
        T resp = null;
        if(!estaVacia()){
           resp=ultimo.getDato();
           if(primero == ultimo){
               primero=null;
               ultimo=null;
           }else{
               ultimo = ultimo.getAnterior();
               ultimo.getSiguiente().setAnterior(null);
               ultimo.setSiguiente(null);
           }
        }
        return resp;
    }
    
    public T contiene(T dato){
        return contiene(dato, iterator());
    }
    
    private T contiene(T dato, Iterator<T> it){
        if(it.hasNext()){
            T aux = it.next();
            if(aux.equals(dato)){
                return aux;
            }else{
                return contiene(dato, it);
            }
        }else{
            return null;
        }
    }
    
    public boolean agregaAntesQue(T refer, T dato){
        boolean resp= false;
        if(!estaVacia()){
            if(refer.equals(primero.getDato())){
                resp=true;
                agregaPrimero(dato);
            }else{
                resp = agregaAntesQue(refer, dato, primero.getSiguiente());
            }
        }
        return resp;
    }
    
    private boolean agregaAntesQue(T refer, T dato, NodoDoble<T> apunt){
        if(apunt != null){
            if(apunt.getDato().equals(refer)){
                NodoDoble<T> nuevo = new NodoDoble(dato);
                nuevo.setAnterior(apunt.getAnterior());
                nuevo.setSiguiente(apunt);
                nuevo.getAnterior().setSiguiente(nuevo);
                apunt.setAnterior(nuevo);
                return true;
            }else{
                return agregaAntesQue(refer, dato, apunt.getSiguiente());
            }
        }else{
            return false;
        }
    }
    
    //Es palindromo
    public boolean esPalindromo(){
        if(this.estaVacia()){
            throw new RuntimeException();
        }
        boolean resp = true;
        StringBuilder str1 = new StringBuilder();
        StringBuilder str2 = new StringBuilder();
        NodoDoble<T> aux1= primero;
        NodoDoble<T> aux2 = ultimo;
        while(aux1!=null && resp){
            if(aux1.getDato().equals(aux2)){
                aux1 = aux1.getSiguiente();
                aux2=aux2.getAnterior();
            }else{
                resp=false;
            }
        }
        return resp;
    }
}
