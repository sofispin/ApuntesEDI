/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nodos;

import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 *
 * @author SOFIA
 */
public class EstructuraEnlazada<T> implements Iterable<T> {

    private Nodo<T> prim, ult; //primer y ultimo nodo SON PUNTEROS.
    //Cuandoestas en esta clase, recorres el arreglo usando el prim.get Dir y asi
    //Si estas afuera, usas un iterador. 

    public EstructuraEnlazada() {
        prim = null;
        ult = null;
    }

    public Iterator<T> iterator() {
        return new IteradorEE(prim);
    }
    
    public boolean estaVacio() {
        return prim == null;
    }
    
    public void agregaInicio(T dato) {
        Nodo<T> nuevo = new Nodo(dato);
        nuevo.setDir(prim);
        prim = nuevo;

        if (ult == null) { //Si es el primero que agrego. 
            ult = nuevo;
        }
    }

    public void agregaUltimo(T dato) {
        Nodo<T> nuevo = new Nodo(dato);
        if (estaVacio()) {
            prim = nuevo;
        } else {
            ult.setDir(nuevo);
        }
        ult = nuevo;
    }

    //toString recursivo utilizando direcciones
    public String toString() {
        return toString(prim, new StringBuilder());
    }

    private String toString(Nodo<T> ap, StringBuilder str) {
        if (ap != null) {
            str.append(ap.getDato());
            return toString(ap.getDir(), str);
        } else {
            return str.toString();
        }
    }

    //Iterativo
    public String toStringIterativo() {
        return toStringIterativo(iterator(), new StringBuilder());
    }

    private String toStringIterativo(Iterator<T> it, StringBuilder str) {
        if (it.hasNext()) {
            str.append(it.next());
            return toStringIterativo(it, str);
        } else {
            return str.toString();
        }
    }

    public T eliminaPrim() {
        T res;
        if (estaVacio()) {
            res = null;
        } else {
            res = prim.getDato();
            Nodo<T> aux = prim;
            prim = prim.getDir();//Primero ahora es el siguiente. 
            if (prim == null) { // Si solo tienes un dato
                ult = null;
            } else {
                aux.setDir(null);//Se rompe la relacion entre el que elimino y el resto de mis nodos. 
            }
        }
        return res;
    }

    public T consultaPrimero() {
        T res = null;
        if (!estaVacio()) {
            res = prim.getDato();
        }
        return res;
    }

    public T buscaDato(T dato) {
        if(dato== null){
            throw new NullPointerException();
        }
        return buscaDato(dato, prim);
    }

    private T buscaDato(T dato, Nodo<T> ap) {
        if (ap == null) {
            return null;
        } else {
            if (ap.getDato().equals(dato)) {
                return dato;
            } else {
                return buscaDato(dato, ap.getDir()); //Entra con la direccion del que sigue: es el avance. 
            }
        }
    }

    public T eliminaDato(T dato) {
        if (prim == null || dato == null) {
            throw new NullPointerException();
        } else if (prim.getDato().equals(dato)) {
            return eliminaPrim();
        } else if (ult.getDato().equals(dato)) {
            return eliminaUltimo();
        } else {
            return eliminaDato(dato, prim, null);
        }
    }

    private T eliminaDato(T dato, Nodo<T> p, Nodo<T> q) {
        if (p == null) {
            return null;
        } else if (p.getDato().equals(dato)) {
            /*if (p == prim) {
                return eliminaPrim();
            } else {*/
            Nodo<T> aux = p.getDir();
            q.setDir(aux);
            p.setDir(null);
            // }
            return p.getDato();
        } else {
            return eliminaDato(dato, p.getDir(), p);
        }
    }

    public T eliminaUltimo() {
        T res = null;
        if (!estaVacio()) {
            res = ult.getDato();
            if (prim == ult) { // Si solo tienes un dato
                prim = null;
                ult = null;
            } else {
                Nodo<T> aux = prim;
                while (aux.getDir() != ult) {
                    aux = aux.getDir();
                }
                aux.setDir(null);//Se rompe la relacion entre el que elimino y el resto de mis nodos.
                ult = aux;
            }
        }
        return res;
    }

//    public boolean eliminaAnterior(T dato){
//        if (prim == null || dato == null) {
//            throw new NullPointerException();
//        }
//        if(prim == ult){
//            return false;
//        }else if(buscaDato(dato) == null){
//            return false;
//        }else if(prim.getDir().getDato().equals(dato)){
//            eliminaPrim();
//            return true;
//        }else{
//            Nodo<T> aux = prim;
//            return eliminaAnterior(dato, prim, null, aux);
//        }
//    }
//    
//    private boolean eliminaAnterior(T dato, Nodo<T> p, Nodo<T> u, Nodo<T> aux){
//        if(p==null){
//            return false;
//        }else if(p.getDir().getDato().equals(dato)){
//            return eliminaAnterior(dato, p.getDir(), u, p);
//        }else{
//            
//            return true;
//        }
//    }
    public T eliminaAnterior(T dato) {
        if (!estaVacio() && dato != null) {
            if (prim.getDato().equals(dato) || prim == ult) {
                return null;
            } else {
                return eliminaAnterior(dato, prim.getDir(), prim, null);
            }
        } else {
            throw new NoSuchElementException();
        }
    }

    private T eliminaAnterior(T dato, Nodo<T> n1, Nodo<T> n2, Nodo<T> n3) {
        if (n1.getDato().equals(dato)) {
            if (n3 == null) {
                return eliminaPrim();
            } else {
                n3.setDir(n1);
                n2.setDir(null);
                return n2.getDato();
            }
        } else {
            if (n1 == ult) {
                return null;
            } else {
                return eliminaAnterior(dato, n1.getDir(), n1, n2);
            }
        }
    }

    //TAREA
    //Ejercicio 33 y 34
    public boolean eliminaSiguienteA(T dato) {
        boolean resp = false;
        if (dato == null || estaVacio()) {
            throw new NullPointerException();
        }
        Nodo<T> aux1;
        Nodo<T> aux2;
        if (prim != ult) {
            aux1 = prim;
            while (aux1 != null && !aux1.getDato().equals(dato)) {
                aux1 = aux1.getDir();
            }
            if (aux1 != null && aux1 != ult) {
                if (aux1.getDir() == ult) {
                    aux2 = aux1.getDir();
                    aux1.setDir(aux2.getDir());
                    resp = true;
                    if (aux2 == ult) {
                        ult = aux1;
                    } else {
                        aux2.setDir(null);
                    }
                }

            }
        }
        return resp;
    }

    public boolean insertaAntesQue(T refer, T nuevo) {
        if (estaVacio() || refer == null || nuevo == null) {
            throw new NullPointerException();
        }
        boolean resp = false;
        Nodo<T> insert = new Nodo(nuevo);
        if (prim.getDato().equals(refer)) {
            insert.setDir(prim);
            prim = insert;
            resp = true;
        } else {
            Nodo<T> aux = prim;
            while (aux.getDir() != null && !aux.getDir().getDato().equals(refer)) {
                insert.setDir(aux.getDir());
                aux.setDir(insert);
                resp = true;
            }
        }
        return resp;
    }

    public int eliminaTodosRepetidosOrdenados() {
        if (estaVacio()) {
            throw new RuntimeException();
        }
        Nodo <T> aux = prim;
        int cont = 0;

        if (prim != ult) {
            while (aux != null) {
                if (aux.getDir().getDato().equals(aux.getDato())) {
                    Nodo<T> aux2 = aux.getDir();
                    if (aux.getDir() == ult) {
                        ult = aux;
                        aux.setDir(null);
                    } else {
                        aux.setDir(aux.getDir().getDir());
                        aux2.setDir(null);
                    }
                    cont++;
                } else {
                    aux.setDir(aux.getDir());
                }
            }
        }

        return cont;
    }

    //Ejercicio 36 y 37
    public int eliminaTodosRepetidosDesordenado() {
        if (estaVacio()) {
            throw new RuntimeException();
        }
        int resp = 0;
        if (prim != null) {
            Nodo<T> aux = prim;
            Nodo<T> aux2, aux3;
            while (aux != ult) {
                aux3 = aux;
                aux2 = aux;
                while (aux2 != ult) {
                        aux2 = aux3.getDir();
                        if (aux.getDato().equals(aux2.getDato())) {
                            aux3.setDir(aux2.getDir());
                            aux2.setDir(null);
                            resp++;
                        } else {
                            aux3 = aux3.getDir();
                        }
                        if(prim.getDir() == null){
                            ult = prim;
                        }else{
                            aux = prim;
                        }
                        if (aux2 == ult) {
                            if (aux.getDato().equals(aux2.getDato())) {
                                aux3.setDir(null);
                                ult = aux3;
                                resp++;
                            }
                        }
                    }
                    aux = aux.getDir();
                }
                aux.setDir(aux.getDir());
            }
            return resp;
        }
    
    

    

    

    public void insertaIntercalado(EstructuraEnlazada otra) {
        if(otra != null && !otra.estaVacio()){
            Nodo<T> aux, aux1, aux2, aux3;
            if(prim!= ult){
                aux = prim;
                aux1 = prim.getDir();
                aux2 = otra.prim;
                aux3 = otra.prim.getDir();
                while(aux1 != null && aux3 != null){
                    aux.setDir(aux2);
                    aux2.setDir(aux1);
                    aux2 = aux3;
                    aux3 = aux3.getDir();
                    aux = aux1;
                    aux1 = aux1.getDir();
                }
                if(aux1 == null && aux3 == null){
                    aux.setDir(aux2);
                    ult = aux2;
                }else if(aux1 == null && aux3 != null){
                    ult.setDir(aux2);
                    ult = otra.ult;
                }else{
                    aux.setDir(aux2);
                    aux2.setDir(aux1);
                }
            }else{
                if(estaVacio()){
                    prim = otra.prim;
                    ult = otra.ult;
                }else{
                    prim.setDir(otra.prim);
                    ult = otra.ult;
                }
            }
        }

    }
    
    //Ejercicio 38
    //Reescribe Pila y Cola con EE
    
    
}
