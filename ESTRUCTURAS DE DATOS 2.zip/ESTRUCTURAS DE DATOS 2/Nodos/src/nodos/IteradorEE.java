/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nodos;
import java.util.*;
/**
 *
 * @author SOFIA
 */
public class IteradorEE <T> implements Iterator <T>{
    private Nodo <T> actual; //Guarda la dreccion de un nodo
    
    public IteradorEE(Nodo <T> nodo){
        actual = nodo;
    }
    
    public boolean hasNext(){
        return actual != null;
    }
    
    public T next(){
        if(!hasNext()){
            throw new NoSuchElementException();
        }
        T res = actual.getDato();
        actual = actual.getDir();
        return res;
    }
    
    public void remove(){
        throw new UnsupportedOperationException("No esta implementado");
    }
}
