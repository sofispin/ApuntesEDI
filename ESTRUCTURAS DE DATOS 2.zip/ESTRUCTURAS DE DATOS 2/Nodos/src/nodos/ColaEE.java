/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nodos;
import colas.*;
/**
 *
 * @author SOFIA
 */
public class ColaEE <T> implements  ColaADT<T>{
    public EstructuraEnlazada<T> cola;
    
    public ColaEE(){
        cola = new EstructuraEnlazada();
    }
    
    public void insertar(T dato){
        cola.agregaUltimo(dato);
    }
    
    public T eliminar(){
        if(isEmpty()){
            throw new EmptyCollectionException();
        }
       return cola.eliminaPrim();
    }
    
    public T consultaPrimero(){
        if(isEmpty()){
            throw new EmptyCollectionException();
        }
        return cola.consultaPrimero();
    }
    
    public boolean isEmpty(){
        return cola.estaVacio();
    }
}
