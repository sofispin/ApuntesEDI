/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nodos;
import pilas.*;
/**
 *
 * @author SOFIA
 */
public class PilaEE <T> implements PilaADT<T>{
    public EstructuraEnlazada<T> pila;
    
    public PilaEE(){
        pila = new EstructuraEnlazada();
    }
    
    public void push (T dato){
        pila.agregaInicio(dato);
    }
    
    public T pop(){
        if(isEmpty()){
            throw new EmptyCollectionException();
        }
       return pila.eliminaPrim();
    }
    
    public T peek(){
        if(isEmpty()){
            throw new EmptyCollectionException();
        }
        return pila.consultaPrimero();
    }
    
    public boolean isEmpty(){
        return pila.estaVacio();
    }
}
